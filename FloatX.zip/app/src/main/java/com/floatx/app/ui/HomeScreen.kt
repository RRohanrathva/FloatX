@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.floatx.app.ui

import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.floatx.app.data.Prefs
import com.floatx.app.shizuku.ShizukuManager
import kotlin.math.roundToInt

@Composable
fun HomeScreen(pad: PaddingValues, resumeTick: Int, actions: RootActions) {
    val ctx = LocalContext.current
    val sz by ShizukuManager.state.collectAsState()
    val overlayOk = remember(resumeTick) { Settings.canDrawOverlays(ctx) }
    var sidebarOn by remember { mutableStateOf(Prefs.sidebarEnabled) }
    var right by remember { mutableStateOf(Prefs.rightSide) }
    var pct by remember { mutableFloatStateOf(Prefs.windowPercent.toFloat()) }
    val ready = sz.ready && overlayOk

    LazyColumn(
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = pad.calculateTopPadding() + 4.dp,
            bottom = pad.calculateBottomPadding() + 16.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { HeroCard(ready) }

        item {
            SectionCard("Setup") {
                StepRow(
                    done = sz.running,
                    title = if (sz.running) "Shizuku is running" else if (sz.installed) "Start Shizuku" else "Install Shizuku",
                    desc = "Needed to open apps in floating windows. Start it with Wireless debugging or root.",
                    action = "Open",
                    onAction = actions.openShizuku,
                )
                StepRow(
                    done = sz.granted,
                    title = if (sz.granted) "Permission granted" else "Allow FloatX in Shizuku",
                    desc = "Lets FloatX run the window command.",
                    action = "Grant",
                    enabled = sz.running,
                    onAction = actions.requestShizukuPermission,
                )
                StepRow(
                    done = overlayOk,
                    title = if (overlayOk) "Overlay allowed" else "Allow display over other apps",
                    desc = "Needed for the edge sidebar.",
                    action = "Allow",
                    onAction = actions.requestOverlay,
                )
            }
        }

        item {
            SectionCard("Sidebar") {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Edge sidebar",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            "Swipe from the edge to pick an app",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    val checked = sidebarOn && overlayOk
                    Switch(
                        checked = checked,
                        onCheckedChange = { on ->
                            if (on && !overlayOk) {
                                actions.requestOverlay()
                            } else {
                                sidebarOn = on
                                actions.toggleSidebar(on)
                            }
                        },
                        thumbContent = if (checked) {
                            { Icon(Icons.Rounded.Check, null, Modifier.size(SwitchDefaults.IconSize)) }
                        } else null,
                    )
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    "Edge",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp, bottom = 6.dp),
                )
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = !right,
                        onClick = { right = false; Prefs.rightSide = false; actions.sideChanged() },
                        shape = SegmentedButtonDefaults.itemShape(0, 2),
                    ) { Text("Left") }
                    SegmentedButton(
                        selected = right,
                        onClick = { right = true; Prefs.rightSide = true; actions.sideChanged() },
                        shape = SegmentedButtonDefaults.itemShape(1, 2),
                    ) { Text("Right") }
                }
            }
        }

        item {
            SectionCard("Floating window") {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "Window size",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        "${pct.roundToInt()}%",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Slider(
                    value = pct,
                    onValueChange = { pct = it },
                    onValueChangeFinished = { Prefs.windowPercent = pct.roundToInt() },
                    valueRange = 50f..95f,
                )
            }
        }
    }
}

@Composable
private fun HeroCard(ready: Boolean) {
    Surface(
        shape = RoundedCornerShape(44.dp),
        color = if (ready) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.tertiaryContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(26.dp)) {
            Box(
                Modifier
                    .size(60.dp)
                    .background(
                        if (ready) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary,
                        RoundedCornerShape(22.dp),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (ready) Icons.Rounded.PlayArrow else Icons.Rounded.Warning,
                    contentDescription = null,
                    tint = if (ready) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onTertiary,
                    modifier = Modifier.size(32.dp),
                )
            }
            Spacer(Modifier.height(18.dp))
            Text(
                if (ready) "Ready to float" else "Almost there",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = if (ready) MaterialTheme.colorScheme.onPrimaryContainer
                else MaterialTheme.colorScheme.onTertiaryContainer,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (ready) "Open any app in a floating window from the Apps tab or the edge sidebar."
                else "Finish the setup steps below to start using floating windows.",
                style = MaterialTheme.typography.bodyLarge,
                color = if (ready) MaterialTheme.colorScheme.onPrimaryContainer
                else MaterialTheme.colorScheme.onTertiaryContainer,
            )
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Surface(
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp, bottom = 6.dp),
            )
            content()
        }
    }
}

@Composable
private fun StepRow(
    done: Boolean,
    title: String,
    desc: String,
    action: String,
    onAction: () -> Unit,
    enabled: Boolean = true,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(40.dp)
                .background(
                    if (done) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceContainerHighest,
                    CircleShape,
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (done) Icons.Rounded.CheckCircle else Icons.Rounded.Warning,
                contentDescription = null,
                tint = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(22.dp),
            )
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(
                desc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (!done) {
            FilledTonalButton(onClick = onAction, enabled = enabled) { Text(action) }
        }
    }
}
