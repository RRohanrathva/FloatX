# FloatX

Floating app windows for Android 11 – 17 using **Shizuku**, in the style of Mi-Freeform:
each app runs on a private virtual display shown inside FloatX's own window.

## Window controls
- **Press & hold the dots at the top** and move to drag the window.
- **Drag a bottom corner** (left or right arc) to resize. The whole window - app picture,
  handle, buttons and corners - scales together, so nothing changes position or proportion.
- **Swipe up on the pill at the bottom** to close the window (stops the app).
- Left of the pill: **fullscreen** toggle (pull the top handle down to leave fullscreen).
  Right of the pill: **back**.
- Edge sidebar: swipe the pill on the screen edge to pick an app.

## Build on GitHub
Upload `FloatX.zip` + `.github/workflows/build.yml`, open Actions, download `FloatX-apk`.

## Setup on the phone
1. Start Shizuku. 2. Grant FloatX in Shizuku. 3. Allow display over other apps. 4. Turn on Edge sidebar.

## Known limits
- Typing with the keyboard inside a floating window may not work on some ROMs.
- Some ROMs/Android versions restrict virtual displays; the app shows a message if blocked.
