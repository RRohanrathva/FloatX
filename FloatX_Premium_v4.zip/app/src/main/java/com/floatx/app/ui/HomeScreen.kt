package com.floatx.app.ui

import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.floatx.app.data.Prefs
import com.floatx.app.shizuku.ShizukuManager
import com.floatx.app.window.FloatHostService
import kotlin.math.roundToInt

@Composable
fun HomeScreen(pad: PaddingValues, resumeTick: Int, actions: RootActions) {
    val ctx = LocalContext.current
    val sz by ShizukuManager.state.collectAsState()
    val overlayOk = remember(resumeTick) { Settings.canDrawOverlays(ctx) }
    var sidebarOn by remember { mutableStateOf(Prefs.sidebarEnabled) }
    var right by remember { mutableStateOf(Prefs.rightSide) }
    var pct by remember { mutableFloatStateOf(Prefs.windowPercent.toFloat()) }

    // DPI states
    val defaultDpi = ctx.resources.displayMetrics.densityDpi
    var savedDpi by remember { mutableIntStateOf(Prefs.windowDpi) }
    var dpiInput by remember {
        mutableStateOf(if (Prefs.windowDpi > 0) Prefs.windowDpi.toString() else "")
    }

    // Sidebar customization states
    var sbOffset by remember { mutableFloatStateOf(Prefs.sidebarOffsetPercent.toFloat()) }
    var sbHeight by remember { mutableFloatStateOf(Prefs.sidebarHeightDp.toFloat()) }
    var sbThickness by remember { mutableFloatStateOf(Prefs.sidebarThicknessDp.toFloat()) }

    val ready = sz.ready && overlayOk

    LazyColumn(
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = pad.calculateTopPadding() + 4.dp,
            bottom = pad.calculateBottomPadding() + 20.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { HeroCard(ready) }

        item {
            SectionCard("Setup") {
                StepRow(
                    done = sz.running,
                    title = if (sz.running) "Shizuku is running" else if (sz.installed) "Start Shizuku" else "Install Shizuku",
                    desc = "Needed to open apps in floating windows. Start it with Wireless debugging or root.",
                    action = "Open",
                    onAction = actions.openShizuku,
                )
                StepRow(
                    done = sz.granted,
                    title = if (sz.granted) "Permission granted" else "Allow FloatX in Shizuku",
                    desc = "Lets FloatX run the window command.",
                    action = "Grant",
                    enabled = sz.running,
                    onAction = actions.requestShizukuPermission,
                )
                StepRow(
                    done = overlayOk,
                    title = if (overlayOk) "Overlay allowed" else "Allow display over other apps",
                    desc = "Needed for floating windows and edge sidebar.",
                    action = "Allow",
                    onAction = actions.requestOverlay,
                )
            }
        }

        item {
            SectionCard("Edge Sidebar Customization") {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Edge sidebar",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            "Swipe from the edge to pick an app",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    val checked = sidebarOn && overlayOk
                    Switch(
                        checked = checked,
                        onCheckedChange = { on ->
                            if (on && !overlayOk) {
                                actions.requestOverlay()
                            } else {
                                sidebarOn = on
                                actions.toggleSidebar(on)
                            }
                        },
                        thumbContent = if (checked) {
                            { Icon(Icons.Rounded.Check, null, Modifier.size(SwitchDefaults.IconSize)) }
                        } else null,
                    )
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    "Screen Edge",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp, bottom = 6.dp),
                )
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = !right,
                        onClick = { right = false; Prefs.rightSide = false; actions.sideChanged() },
                        shape = SegmentedButtonDefaults.itemShape(0, 2),
                    ) { Text("Left") }
                    SegmentedButton(
                        selected = right,
                        onClick = { right = true; Prefs.rightSide = true; actions.sideChanged() },
                        shape = SegmentedButtonDefaults.itemShape(1, 2),
                    ) { Text("Right") }
                }

                Spacer(Modifier.height(12.dp))

                // Vertical position (Up / Down)
                SliderSettingRow(
                    label = "Vertical Position (Up / Down)",
                    valueText = when {
                        sbOffset.roundToInt() < 0 -> "${sbOffset.roundToInt()}% (Up)"
                        sbOffset.roundToInt() > 0 -> "+${sbOffset.roundToInt()}% (Down)"
                        else -> "Center"
                    },
                    value = sbOffset,
                    range = -40f..40f,
                    onChange = { sbOffset = it },
                    onFinished = {
                        Prefs.sidebarOffsetPercent = sbOffset.roundToInt()
                        actions.sideChanged()
                    },
                )

                // Length (Nano / Moto)
                SliderSettingRow(
                    label = "Sidebar Length (Small / Large)",
                    valueText = "${sbHeight.roundToInt()} dp",
                    value = sbHeight,
                    range = 70f..260f,
                    onChange = { sbHeight = it },
                    onFinished = {
                        Prefs.sidebarHeightDp = sbHeight.roundToInt()
                        actions.sideChanged()
                    },
                )

                // Thickness (Jadu / Patalu)
                SliderSettingRow(
                    label = "Sidebar Thickness (Thin / Thick)",
                    valueText = "${sbThickness.roundToInt()} dp",
                    value = sbThickness,
                    range = 3f..12f,
                    onChange = { sbThickness = it },
                    onFinished = {
                        Prefs.sidebarThicknessDp = sbThickness.roundToInt()
                        actions.sideChanged()
                    },
                )

                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.End,
                ) {
                    FilledTonalButton(
                        onClick = {
                            sbOffset = 0f
                            sbHeight = 145f
                            sbThickness = 5f
                            Prefs.sidebarOffsetPercent = 0
                            Prefs.sidebarHeightDp = 145
                            Prefs.sidebarThicknessDp = 5
                            actions.sideChanged()
                        }
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Reset Sidebar")
                    }
                }
            }
        }

        item {
            SectionCard("Floating Window & DPI") {
                SliderSettingRow(
                    label = "Default Window Size",
                    valueText = "${pct.roundToInt()}%",
                    value = pct,
                    range = 50f..95f,
                    onChange = { pct = it },
                    onFinished = { Prefs.windowPercent = pct.roundToInt() },
                )

                Spacer(Modifier.height(10.dp))

                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Floating Window DPI",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            if (savedDpi > 0) "Active: $savedDpi DPI (Device: $defaultDpi)"
                            else "Active: Auto ($defaultDpi DPI)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(
                        onClick = {
                            savedDpi = 0
                            dpiInput = ""
                            Prefs.windowDpi = 0
                            FloatHostService.updateDpi(ctx)
                        }
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = "Reset DPI")
                    }
                }

                Spacer(Modifier.height(8.dp))

                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    OutlinedTextField(
                        value = dpiInput,
                        onValueChange = { raw ->
                            dpiInput = raw.filter { it.isDigit() }.take(3)
                        },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(18.dp),
                        placeholder = { Text("e.g. 240, 320, 420") },
                        label = { Text("Custom DPI (120–640)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    )
                    FilledTonalButton(
                        onClick = {
                            val parsed = dpiInput.toIntOrNull()
                            if (parsed != null && parsed in 120..640) {
                                savedDpi = parsed
                                Prefs.windowDpi = parsed
                                FloatHostService.updateDpi(ctx)
                            }
                        },
                        enabled = (dpiInput.toIntOrNull() ?: 0) in 120..640,
                    ) {
                        Text("Apply")
                    }
                }
            }
        }
    }
}

@Composable
private fun SliderSettingRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    onFinished: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                label,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            Text(
                valueText,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
            )
        }
        Slider(
            value = value,
            onValueChange = onChange,
            onValueChangeFinished = onFinished,
            valueRange = range,
        )
    }
}

@Composable
private fun HeroCard(ready: Boolean) {
    val bgColor by animateColorAsState(
        targetValue = if (ready) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.tertiaryContainer,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "heroBg",
    )
    val badgeColor by animateColorAsState(
        targetValue = if (ready) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "heroBadge",
    )
    val badgeScale by animateFloatAsState(
        targetValue = if (ready) 1.05f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
        label = "heroScale",
    )

    Surface(
        shape = RoundedCornerShape(44.dp),
        color = bgColor,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(26.dp)) {
            Box(
                Modifier
                    .size(60.dp)
                    .scale(badgeScale)
                    .background(badgeColor, RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (ready) Icons.Rounded.PlayArrow else Icons.Rounded.Warning,
                    contentDescription = null,
                    tint = if (ready) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onTertiary,
                    modifier = Modifier.size(32.dp),
                )
            }
            Spacer(Modifier.height(18.dp))
            Text(
                if (ready) "Ready to float" else "Almost there",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = if (ready) MaterialTheme.colorScheme.onPrimaryContainer
                else MaterialTheme.colorScheme.onTertiaryContainer,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (ready) "Open any app in a floating window from the Apps tab or the edge sidebar."
                else "Finish the setup steps below to start using floating windows.",
                style = MaterialTheme.typography.bodyLarge,
                color = if (ready) MaterialTheme.colorScheme.onPrimaryContainer
                else MaterialTheme.colorScheme.onTertiaryContainer,
            )
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Surface(
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp, bottom = 6.dp),
            )
            content()
        }
    }
}

@Composable
private fun StepRow(
    done: Boolean,
    title: String,
    desc: String,
    action: String,
    onAction: () -> Unit,
    enabled: Boolean = true,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(40.dp)
                .background(
                    if (done) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceContainerHighest,
                    CircleShape,
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (done) Icons.Rounded.CheckCircle else Icons.Rounded.Warning,
                contentDescription = null,
                tint = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(22.dp),
            )
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(
                desc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        AnimatedVisibility(
            visible = !done,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
        ) {
            FilledTonalButton(onClick = onAction, enabled = enabled) { Text(action) }
        }
    }
}
