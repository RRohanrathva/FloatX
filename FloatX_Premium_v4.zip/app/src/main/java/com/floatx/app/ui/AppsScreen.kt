package com.floatx.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.floatx.app.data.AppItem
import com.floatx.app.data.AppRepository
import com.floatx.app.data.Prefs
import com.floatx.app.window.FloatHostService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun AppsScreen(pad: PaddingValues) {
    val ctx = LocalContext.current
    val apps by produceState(initialValue = emptyList<AppItem>()) {
        value = withContext(Dispatchers.IO) { AppRepository.load(ctx) }
    }
    var query by remember { mutableStateOf("") }
    var pinned by remember { mutableStateOf(Prefs.pinned) }

    val shown = remember(apps, query, pinned) {
        apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
            .sortedWith(compareByDescending<AppItem> { it.pkg in pinned }.thenBy { it.label.lowercase() })
    }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = pad.calculateTopPadding() + 4.dp,
            bottom = pad.calculateBottomPadding() + 16.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            TextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search apps") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                shape = RoundedCornerShape(32.dp),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    disabledIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                ),
            )
        }
        item {
            Text(
                "Tap an app to open it floating. Star apps to show only favourites in the sidebar.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
        items(shown, key = { it.pkg }) { app ->
            val isPinned = app.pkg in pinned
            val cardColor by animateColorAsState(
                targetValue = if (isPinned) MaterialTheme.colorScheme.secondaryContainer
                else MaterialTheme.colorScheme.surfaceContainer,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "appCardColor",
            )
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = cardColor,
                modifier = Modifier
                    .fillMaxWidth()
                    .animateItem(
                        placementSpec = spring(
                            dampingRatio = 0.78f,
                            stiffness = Spring.StiffnessMediumLow,
                        )
                    )
                    .clickable { FloatHostService.open(ctx.applicationContext, app.pkg) },
            ) {
                Row(
                    Modifier.padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AppIcon(app.pkg, 48.dp)
                    Box(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text(
                            app.label,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    IconToggleButton(
                        checked = isPinned,
                        onCheckedChange = { on ->
                            val next = if (on) pinned + app.pkg else pinned - app.pkg
                            pinned = next
                            Prefs.pinned = next
                        },
                    ) {
                        Icon(
                            if (isPinned) Icons.Rounded.Star else Icons.Outlined.Star,
                            contentDescription = "Pin",
                            tint = if (isPinned) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        if (apps.isNotEmpty() && shown.isEmpty()) {
            item {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("No apps match", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
