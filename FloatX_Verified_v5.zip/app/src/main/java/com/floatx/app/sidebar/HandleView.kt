package com.floatx.app.sidebar

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.OvershootInterpolator
import com.floatx.app.data.Prefs
import kotlin.math.abs

@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class HandleView(
    context: Context,
    private val rightSide: Boolean,
    private val onOpen: () -> Unit,
) : View(context) {

    private val density = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE67C65C8.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xB3FFFFFF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 1.1f * density
    }
    private val rect = RectF()
    private var downX = 0f
    private var opened = false
    private var stretchFactor = 1f
    private var stretchAnim: ValueAnimator? = null

    init {
        alpha = 0f
        scaleY = 0.75f
        animate()
            .alpha(1f)
            .scaleY(1f)
            .setDuration(260)
            .setInterpolator(OvershootInterpolator(1.2f))
            .start()
    }

    override fun onDraw(canvas: Canvas) {
        val pillW = Prefs.sidebarThicknessDp.coerceIn(3, 12) * density * stretchFactor
        val margin = 3.5f * density
        val left = if (rightSide) width - pillW - margin else margin
        val padV = 6f * density
        rect.set(left, padV, left + pillW, (height - padV).coerceAtLeast(padV + pillW))
        val r = pillW / 2f
        canvas.drawRoundRect(rect, r, r, fill)
        canvas.drawRoundRect(rect, r, r, stroke)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
    }

    private fun animateStretch(target: Float) {
        stretchAnim?.cancel()
        stretchAnim = ValueAnimator.ofFloat(stretchFactor, target).apply {
            duration = 140
            addUpdateListener {
                stretchFactor = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                opened = false
                animateStretch(1.35f)
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val towardCenter = if (rightSide) -dx else dx
                if (!opened && towardCenter > slop * 1.8f) {
                    opened = true
                    performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    animateStretch(1f)
                    onOpen()
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animateStretch(1f)
                if (e.actionMasked == MotionEvent.ACTION_UP && !opened && abs(e.rawX - downX) < slop) {
                    performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    onOpen()
                }
            }
        }
        return true
    }
}
