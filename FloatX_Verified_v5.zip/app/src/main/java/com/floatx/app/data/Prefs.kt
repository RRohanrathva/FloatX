package com.floatx.app.data

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        sp = context.applicationContext.getSharedPreferences("floatx", Context.MODE_PRIVATE)
    }

    var sidebarEnabled: Boolean
        get() = sp.getBoolean("sidebar", false)
        set(v) = sp.edit().putBoolean("sidebar", v).apply()

    var rightSide: Boolean
        get() = sp.getBoolean("right_side", true)
        set(v) = sp.edit().putBoolean("right_side", v).apply()

    var windowPercent: Int
        get() = sp.getInt("window_percent", 75)
        set(v) = sp.edit().putInt("window_percent", v.coerceIn(50, 95)).apply()

    var windowDpi: Int
        get() = sp.getInt("window_dpi", 0)
        set(v) = sp.edit().putInt("window_dpi", if (v <= 0) 0 else v.coerceIn(120, 640)).apply()

    var sidebarOffsetPercent: Int
        get() = sp.getInt("sidebar_offset_percent", 0)
        set(v) = sp.edit().putInt("sidebar_offset_percent", v.coerceIn(-40, 40)).apply()

    var sidebarHeightDp: Int
        get() = sp.getInt("sidebar_height_dp", 145)
        set(v) = sp.edit().putInt("sidebar_height_dp", v.coerceIn(70, 260)).apply()

    var sidebarThicknessDp: Int
        get() = sp.getInt("sidebar_thickness_dp", 5)
        set(v) = sp.edit().putInt("sidebar_thickness_dp", v.coerceIn(3, 12)).apply()

    var pinned: Set<String>
        get() = HashSet(sp.getStringSet("pinned", emptySet()) ?: emptySet())
        set(v) = sp.edit().putStringSet("pinned", HashSet(v)).apply()
}
