package com.floatx.app.window

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.InputDevice
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import com.floatx.app.data.Prefs
import com.floatx.app.shizuku.ShizukuManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

@SuppressLint("ClickableViewAccessibility")
class FloatWindow(
    private val ctx: Context,
    private val wm: WindowManager,
    private val pkg: String,
    private val scope: CoroutineScope,
    private val index: Int,
    private val onClosed: (FloatWindow) -> Unit,
) {
    private val density = ctx.resources.displayMetrics.density
    private val touchSlop = ViewConfiguration.get(ctx).scaledTouchSlop
    private fun dp(v: Int) = (v * density).toInt()

    private val screenW get() = wm.maximumWindowMetrics.bounds.width()
    private val screenH get() = wm.maximumWindowMetrics.bounds.height()

    private val topH = dp(28)
    private val botH = dp(36)
    private val minW = dp(260)
    private val minH = dp(360)
    private val minScale = 0.45f
    private val baseCorner = dp(28).toFloat()
    private val bubbleSize = dp(58)

    private lateinit var root: FrameLayout
    private lateinit var container: FrameLayout
    private lateinit var texture: TextureView
    private var lp: WindowManager.LayoutParams? = null
    private lateinit var cornerLeft: View
    private lateinit var cornerRight: View
    private lateinit var fsIcon: IconView
    private lateinit var centerDotsView: DotsView

    private var bubbleView: FrameLayout? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var popupMenu: PopupWindow? = null

    private var baseW = 0
    private var baseH = 0
    private var cw = 0
    private var ch = 0

    private var cornerPx = baseCorner
    private var hostTexture: SurfaceTexture? = null
    private var surface: Surface? = null
    private var vd: VirtualDisplay? = null
    private var displayId = -1
    private var vdW = 0
    private var vdH = 0
    private var maximized = false
    private var isBubble = false
    private var restore = Rect()
    private var closed = false
    private var closingAnimated = false
    private var anim: ValueAnimator? = null

    private val component: String? =
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToString()

    private val appLabel: String = runCatching {
        val pm = ctx.packageManager
        val info = pm.getApplicationInfo(pkg, 0)
        pm.getApplicationLabel(info).toString()
    }.getOrDefault(pkg)

    private val appIcon = runCatching {
        ctx.packageManager.getApplicationIcon(pkg)
    }.getOrNull()

    private fun effectiveDpi(): Int {
        val custom = Prefs.windowDpi
        return if (custom in 120..640) custom else ctx.resources.displayMetrics.densityDpi
    }

    fun show() {
        val pct = Prefs.windowPercent / 100f
        val base = (min(screenW, screenH) * pct).toInt()
        val w: Int
        val h: Int
        if (screenW <= screenH) {
            w = base
            h = (base * 1.5f).toInt().plus(topH + botH).coerceAtMost((screenH * 0.85f).toInt())
        } else {
            h = base
            w = (base * 1.4f).toInt().coerceAtMost((screenW * 0.85f).toInt())
        }
        baseW = w.coerceAtLeast(minW)
        baseH = h.coerceAtLeast(minH)
        cw = baseW
        ch = baseH

        buildUi()

        val off = (index % 5) * dp(26)
        val params = WindowManager.LayoutParams(
            baseW,
            baseH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = ((screenW - width) / 2 + off).coerceAtLeast(0)
            y = ((screenH - height) / 2 + off).coerceAtLeast(0)
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        lp = params

        root.scaleX = 0.82f
        root.scaleY = 0.82f
        root.alpha = 0f
        wm.addView(root, params)
        root.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(340)
            .setInterpolator(OvershootInterpolator(1.08f))
            .start()
    }

    private fun buildUi() {
        root = FrameLayout(ctx).apply {
            background = GradientDrawable().apply { setColor(0xFF0E0D14.toInt()) }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, cornerPx)
                }
            }
            addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
                v.pivotX = v.width / 2f
                v.pivotY = v.height / 2f
                v.invalidateOutline()
            }
        }

        container = FrameLayout(ctx).apply {
            pivotX = 0f
            pivotY = 0f
        }
        root.addView(container, FrameLayout.LayoutParams(cw, ch))

        texture = TextureView(ctx).apply {
            isOpaque = true
            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                    hostTexture = st
                    if (width > 0 && height > 0) {
                        createDisplay(width, height)
                    }
                }

                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
            setOnTouchListener { _, e ->
                forwardTouch(e)
                true
            }
        }

        val bodyFrame = FrameLayout(ctx).apply {
            setBackgroundColor(0xFF12101A.toInt())
            addView(texture, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        val column = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(buildTopBar(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, topH))
            addView(bodyFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(buildBottomBar(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, botH))
        }
        container.addView(
            column,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )

        cornerLeft = ArcView(ctx, left = true)
        cornerRight = ArcView(ctx, left = false)
        container.addView(cornerLeft, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM or Gravity.START))
        container.addView(cornerRight, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM or Gravity.END))
        attachResize(cornerLeft, fromLeft = true)
        attachResize(cornerRight, fromLeft = false)
    }

    private fun buildTopBar(): FrameLayout {
        val bar = FrameLayout(ctx)
        centerDotsView = DotsView(ctx)
        bar.addView(
            centerDotsView,
            FrameLayout.LayoutParams(dp(48), dp(22), Gravity.CENTER),
        )
        attachTopBarGesture(bar)
        return bar
    }

    private fun buildBottomBar(): LinearLayout {
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(View(ctx), LinearLayout.LayoutParams(dp(36), 1))

        fsIcon = IconView(ctx, IconView.FULLSCREEN).apply {
            setOnClickListener {
                performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                openAsNormalFullScreenApp()
            }
        }
        bar.addView(fsIcon, LinearLayout.LayoutParams(dp(26), dp(26)).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })

        val swipe = FrameLayout(ctx)
        val pill = View(ctx).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(2).toFloat()
                setColor(0xCCFFFFFF.toInt())
            }
        }
        swipe.addView(pill, FrameLayout.LayoutParams(dp(60), dp(4), Gravity.CENTER))
        attachSwipeClose(swipe)
        bar.addView(swipe, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        val back = IconView(ctx, IconView.BACK).apply {
            setOnClickListener {
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                sendKey(KeyEvent.KEYCODE_BACK)
            }
        }
        bar.addView(back, LinearLayout.LayoutParams(dp(26), dp(26)).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })
        bar.addView(View(ctx), LinearLayout.LayoutParams(dp(36), 1))
        return bar
    }

    private fun showCenterDotsMenu(anchor: View) {
        dismissPopupMenu()
        centerDotsView.animate().scaleX(1.22f).scaleY(1.22f).setDuration(130).start()

        val menuCard = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xF71A1826.toInt())
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0x3DFFFFFF)
            }
            setPadding(dp(8), dp(8), dp(8), dp(8))
            elevation = dp(14).toFloat()
            alpha = 0f
            scaleX = 0.9f
            scaleY = 0.9f
        }

        menuCard.addView(createMenuRow("Bubble mode") {
            dismissPopupMenu()
            convertToBubble()
        })

        menuCard.addView(createMenuRow("Split screen") {
            dismissPopupMenu()
            launchInSplitScreen()
        })

        menuCard.addView(createMenuRow("Screenshot") {
            dismissPopupMenu()
            captureWindowScreenshot()
        })

        val pw = PopupWindow(
            menuCard,
            dp(168),
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true,
        ).apply {
            isOutsideTouchable = true
            setBackgroundDrawable(GradientDrawable().apply { setColor(Color.TRANSPARENT) })
            elevation = dp(14).toFloat()
            setOnDismissListener {
                centerDotsView.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                if (popupMenu === this) popupMenu = null
            }
        }
        popupMenu = pw
        val xOff = (anchor.width - dp(168)) / 2
        pw.showAsDropDown(anchor, xOff, dp(4), Gravity.START)
        menuCard.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(190)
            .setInterpolator(OvershootInterpolator(1.1f))
            .start()
    }

    private fun createMenuRow(title: String, onClick: () -> Unit): TextView {
        return TextView(ctx).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = GradientDrawable().apply {
                setColor(0x16FFFFFF)
                cornerRadius = dp(12).toFloat()
            }
            val lpRow = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply {
                topMargin = dp(3)
                bottomMargin = dp(3)
            }
            layoutParams = lpRow
            setOnClickListener {
                performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                onClick()
            }
        }
    }

    private fun dismissPopupMenu() {
        popupMenu?.dismiss()
        popupMenu = null
    }

    private fun attachTopBarGesture(bar: View) {
        var startRawX = 0f
        var startRawY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        var restoredByDrag = false

        bar.setOnTouchListener { v, e ->
            if (closed || closingAnimated) return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = lp?.x ?: 0
                    startY = lp?.y ?: 0
                    dragging = false
                    restoredByDrag = false
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    if (!dragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        dragging = true
                        dismissPopupMenu()
                        root.animate().cancel()
                        root.animate().alpha(0.92f).setDuration(110).start()
                    }
                    if (dragging) {
                        if (maximized) {
                            if (!restoredByDrag && dy > dp(90)) {
                                restoredByDrag = true
                                toggleMaximize()
                            }
                        } else {
                            val curLp = lp ?: return@setOnTouchListener true
                            curLp.x = (startX + dx).toInt().coerceIn(-curLp.width + dp(90), screenW - dp(90))
                            curLp.y = (startY + dy).toInt().coerceIn(0, screenH - topH)
                            updateLayout()
                        }
                    }
                }

                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        root.animate().alpha(1f).setDuration(150).start()
                    } else {
                        if (popupMenu != null) {
                            dismissPopupMenu()
                        } else {
                            bar.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                            showCenterDotsMenu(centerDotsView)
                        }
                    }
                    v.performClick()
                }

                MotionEvent.ACTION_CANCEL -> {
                    root.animate().alpha(1f).setDuration(150).start()
                }
            }
            true
        }
    }

    private fun attachSwipeClose(zone: View) {
        var startRawY = 0f
        val closeThresholdPx = max(dp(72), ((lp?.height ?: minH).coerceAtLeast(minH) * 0.16f).toInt())
        val maxTravelPx = max(dp(180), ((lp?.height ?: minH).coerceAtLeast(minH) * 0.42f).toInt()).toFloat()

        zone.setOnTouchListener { _, e ->
            if (closingAnimated || closed || isBubble) return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dismissPopupMenu()
                    anim?.cancel()
                    root.animate().cancel()
                    startRawY = e.rawY
                }

                MotionEvent.ACTION_MOVE -> {
                    val upDistance = max(0f, startRawY - e.rawY)
                    val progress = (upDistance / maxTravelPx).coerceIn(0f, 1f)
                    val scale = 1f - (0.18f * progress)
                    root.scaleX = scale
                    root.scaleY = scale
                    root.alpha = 1f - (0.75f * progress)
                }

                MotionEvent.ACTION_UP -> {
                    val upDistance = max(0f, startRawY - e.rawY)
                    if (upDistance >= closeThresholdPx) {
                        zone.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                        animateAndClose(kill = true)
                    } else {
                        restoreFromSwipeCancel()
                    }
                }

                MotionEvent.ACTION_CANCEL -> {
                    restoreFromSwipeCancel()
                }
            }
            true
        }
    }

    private fun restoreFromSwipeCancel() {
        if (closed || closingAnimated) return
        root.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(220)
            .setInterpolator(OvershootInterpolator(1.08f))
            .start()
    }

    private fun attachResize(handle: View, fromLeft: Boolean) {
        var startRawX = 0f
        var startRawY = 0f
        var startX = 0
        var startW = 1
        var startH = 1
        handle.setOnTouchListener { _, e ->
            if (maximized || isBubble || closingAnimated) return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dismissPopupMenu()
                    anim?.cancel()
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = lp?.x ?: 0
                    startW = (lp?.width ?: cw).coerceAtLeast(1)
                    startH = (lp?.height ?: ch).coerceAtLeast(1)
                }

                MotionEvent.ACTION_MOVE -> {
                    val curLp = lp ?: return@setOnTouchListener true
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    val kx = (if (fromLeft) -dx else dx) / startW
                    val ky = dy / startH
                    val startS = startW.toFloat() / cw
                    val availW = if (fromLeft) startX + startW else screenW - startX
                    val availH = screenH - curLp.y
                    val maxS = max(minScale, min(availW.toFloat() / cw, availH.toFloat() / ch))
                    val s = (startS * (1f + (kx + ky) / 2f)).coerceIn(minScale, maxS)
                    val nw = (cw * s).toInt()
                    val nh = (ch * s).toInt()
                    curLp.width = nw
                    curLp.height = nh
                    if (fromLeft) curLp.x = startX + startW - nw
                    cornerPx = baseCorner * s
                    applyWindow()
                }
            }
            true
        }
    }

    private fun applyWindow() {
        val curLp = lp ?: return
        container.scaleX = curLp.width.toFloat() / cw
        container.scaleY = curLp.height.toFloat() / ch
        root.invalidateOutline()
        updateLayout()
    }

    private fun updateLayout() {
        val curLp = lp ?: return
        if (!closed) runCatching { wm.updateViewLayout(root, curLp) }
    }

    private fun statusBarHeight(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun openAsNormalFullScreenApp() {
        if (closed || closingAnimated) return
        dismissPopupMenu()
        val launchIntent = ctx.packageManager.getLaunchIntentForPackage(pkg)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
        if (launchIntent != null) {
            runCatching { ctx.startActivity(launchIntent) }
        }
        close(kill = false)
    }

    private fun toggleMaximize() {
        if (closed || isBubble) return
        val curLp = lp ?: return
        val to: Rect
        val toCorner: Float
        if (!maximized) {
            restore = Rect(curLp.x, curLp.y, curLp.x + curLp.width, curLp.y + curLp.height)
            to = Rect(0, 0, screenW, screenH)
            toCorner = 0f
            cw = screenW
            ch = screenH
            container.setPadding(0, statusBarHeight(), 0, 0)
            maximized = true
        } else {
            to = Rect(restore)
            toCorner = baseCorner * (restore.width().toFloat() / baseW)
            cw = baseW
            ch = baseH
            container.setPadding(0, 0, 0, 0)
            maximized = false
        }
        container.layoutParams = FrameLayout.LayoutParams(cw, ch)
        val vis = if (maximized) View.GONE else View.VISIBLE
        cornerLeft.visibility = vis
        cornerRight.visibility = vis
        fsIcon.kind = if (maximized) IconView.EXIT_FULLSCREEN else IconView.FULLSCREEN

        val fx = curLp.x
        val fy = curLp.y
        val fw = curLp.width
        val fh = curLp.height
        val fc = cornerPx
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 340
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                curLp.x = (fx + (to.left - fx) * t).toInt()
                curLp.y = (fy + (to.top - fy) * t).toInt()
                curLp.width = (fw + (to.width() - fw) * t).toInt().coerceAtLeast(1)
                curLp.height = (fh + (to.height() - fh) * t).toInt().coerceAtLeast(1)
                cornerPx = fc + (toCorner - fc) * t
                applyWindow()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    curLp.x = to.left
                    curLp.y = to.top
                    curLp.width = to.width()
                    curLp.height = to.height()
                    cornerPx = toCorner
                    applyWindow()
                    root.post { applyDisplaySize() }
                }
            })
            start()
        }
    }

    private fun launchInSplitScreen() {
        val comp = component
        if (comp == null) {
            Toast.makeText(ctx, "Cannot open $appLabel in split screen", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            release()
            animateAndClose(kill = false)
            delay(180)

            val cmd = """
                am start --display 0 --user current -n '$comp' -f 0x10008000
                sleep 0.25
                TASK_ID=${'$'}(am stack list 2>/dev/null | grep -E "$pkg" | head -n1 | sed -n 's/.*taskId=\([0-9]*\).*//p')
                if [ -z "${'$'}TASK_ID" ]; then
                    TASK_ID=${'$'}(dumpsys activity recents 2>/dev/null | grep -B 2 "$pkg" | grep -oE 'taskId=[0-9]+' | head -n1 | cut -d= -f2)
                fi
                if [ -n "${'$'}TASK_ID" ]; then
                    am task set-windowing-mode "${'$'}TASK_ID" 6 2>/dev/null || am task set-windowing-mode "${'$'}TASK_ID" 3 2>/dev/null || true
                fi
                am start --display 0 --user current --windowingMode 6 -n '$comp' -f 0x10008000 2>/dev/null ||                 am start --display 0 --user current --windowingMode 3 -n '$comp' -f 0x10008000 2>/dev/null || true
            """.trimIndent()

            val out = ShizukuManager.exec(cmd)
            if (out == null) {
                runCatching {
                    val fallback = ctx.packageManager.getLaunchIntentForPackage(pkg)?.apply {
                        addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK or
                                Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or
                                Intent.FLAG_ACTIVITY_MULTIPLE_TASK
                        )
                    }
                    if (fallback != null) ctx.startActivity(fallback)
                }
            }
        }
    }

    private fun captureWindowScreenshot() {
        if (closed || closingAnimated) return
        val bmp: Bitmap? = runCatching { texture.bitmap }.getOrNull()
        if (bmp == null) {
            Toast.makeText(ctx, "Unable to capture floating window", Toast.LENGTH_SHORT).show()
            return
        }

        val flashOverlay = View(ctx).apply {
            setBackgroundColor(0xCCFFFFFF.toInt())
            alpha = 0.85f
        }
        container.addView(
            flashOverlay,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        flashOverlay.animate()
            .alpha(0f)
            .setDuration(240)
            .withEndAction { container.removeView(flashOverlay) }
            .start()

        scope.launch(Dispatchers.IO) {
            val saved = saveBitmapToGallery(bmp)
            withContext(Dispatchers.Main) {
                if (saved) {
                    Toast.makeText(ctx, "Screenshot saved ($appLabel)", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(ctx, "Failed to save screenshot", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun saveBitmapToGallery(bitmap: Bitmap): Boolean {
        val fileName = "FloatX_${appLabel.replace(Regex("[^a-zA-Z0-9_-]"), "_")}_${System.currentTimeMillis()}.png"
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/FloatX")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = ctx.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
                resolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                true
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "FloatX",
                ).apply { mkdirs() }
                val file = File(dir, fileName)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                true
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun convertToBubble() {
        if (closed || isBubble || closingAnimated) return
        isBubble = true

        root.animate()
            .scaleX(0.35f)
            .scaleY(0.35f)
            .alpha(0f)
            .setDuration(190)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .withEndAction {
                if (!isBubble || closed) return@withEndAction
                runCatching { wm.removeView(root) }
                showBubbleOverlay()
            }
            .start()
    }

    private fun showBubbleOverlay() {
        if (bubbleView != null || closed) return

        val curLp = lp
        val marginEdge = dp(6)
        val startOnRight = if (curLp != null) (curLp.x + curLp.width / 2) >= (screenW / 2) else true
        val startX = if (startOnRight) (screenW - bubbleSize - marginEdge) else marginEdge
        val startY = (curLp?.y ?: dp(140)).coerceIn(dp(64), max(dp(64), screenH - bubbleSize - dp(96)))

        val bLp = WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = startX
            y = startY
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }

        val bView = FrameLayout(ctx).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF181622.toInt())
                setStroke(dp(2), 0x80FFFFFF.toInt())
            }
            elevation = dp(12).toFloat()
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            val icon = ImageView(ctx).apply {
                setImageDrawable(appIcon)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            addView(
                icon,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                ).apply {
                    val pad = dp(8)
                    setMargins(pad, pad, pad, pad)
                },
            )
            scaleX = 0.45f
            scaleY = 0.45f
            alpha = 0f
        }

        var downRawX = 0f
        var downRawY = 0f
        var initX = 0
        var initY = 0
        var moved = false

        bView.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = e.rawX
                    downRawY = e.rawY
                    initX = bLp.x
                    initY = bLp.y
                    moved = false
                    bView.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downRawX
                    val dy = e.rawY - downRawY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) {
                        moved = true
                    }
                    if (moved) {
                        bLp.x = (initX + dx).toInt().coerceIn(0, max(0, screenW - bubbleSize))
                        bLp.y = (initY + dy).toInt().coerceIn(dp(24), max(dp(24), screenH - bubbleSize - dp(24)))
                        runCatching { wm.updateViewLayout(bView, bLp) }
                    }
                }

                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        bView.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                        bView.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                        restoreFromBubble()
                    } else {
                        val snapRight = (bLp.x + bubbleSize / 2) >= (screenW / 2)
                        val targetX = if (snapRight) (screenW - bubbleSize - marginEdge) else marginEdge
                        val targetY = bLp.y.coerceIn(dp(24), max(dp(24), screenH - bubbleSize - dp(24)))
                        val fromX = bLp.x
                        val fromY = bLp.y
                        ValueAnimator.ofFloat(0f, 1f).apply {
                            duration = 210
                            interpolator = OvershootInterpolator(1.05f)
                            addUpdateListener { a ->
                                val t = a.animatedValue as Float
                                bLp.x = (fromX + (targetX - fromX) * t).toInt()
                                bLp.y = (fromY + (targetY - fromY) * t).toInt()
                                runCatching { wm.updateViewLayout(bView, bLp) }
                            }
                            start()
                        }
                        bView.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                    }
                    v.performClick()
                }

                MotionEvent.ACTION_CANCEL -> {
                    bView.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
            }
            true
        }

        bubbleView = bView
        bubbleLp = bLp
        runCatching {
            wm.addView(bView, bLp)
            bView.animate()
                .scaleX(1f)
                .scaleY(1f)
                .alpha(1f)
                .setDuration(240)
                .setInterpolator(OvershootInterpolator(1.18f))
                .start()
        }
    }

    private fun restoreFromBubble() {
        if (!isBubble || closed) return
        isBubble = false
        val bv = bubbleView
        bubbleView = null
        bubbleLp = null
        bv?.let { runCatching { wm.removeView(it) } }

        val curLp = lp ?: return
        root.scaleX = 0.72f
        root.scaleY = 0.72f
        root.alpha = 0f
        runCatching {
            wm.addView(root, curLp)
            root.animate()
                .scaleX(1f)
                .scaleY(1f)
                .alpha(1f)
                .setDuration(260)
                .setInterpolator(OvershootInterpolator(1.06f))
                .start()
        }
    }

    private fun removeBubbleNow() {
        isBubble = false
        val bv = bubbleView
        bubbleView = null
        bubbleLp = null
        bv?.let { runCatching { wm.removeView(it) } }
    }

    private fun createDisplay(w: Int, h: Int) {
        val st = hostTexture ?: return
        st.setDefaultBufferSize(w, h)
        val s = Surface(st)
        surface = s

        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val dpi = effectiveDpi()
        val base = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
        val supportsTouch = 1 shl 6

        val display = try {
            dm.createVirtualDisplay("floatx-$pkg", w, h, dpi, s, base or supportsTouch)
        } catch (_: Throwable) {
            try {
                dm.createVirtualDisplay("floatx-$pkg", w, h, dpi, s, base)
            } catch (_: Throwable) {
                null
            }
        }
        if (display == null) {
            Toast.makeText(ctx, "This device blocked the floating display", Toast.LENGTH_LONG).show()
            close(kill = false)
            return
        }
        vd = display
        vdW = w
        vdH = h
        displayId = display.display.displayId

        val comp = component
        if (comp == null) {
            close(kill = false)
            return
        }
        scope.launch {
            delay(80)
            if (closed || displayId < 0) return@launch
            ShizukuManager.exec(
                """
                cmd activity start-activity --display $displayId --user current -n '$comp' -f 0x18000000 2>/dev/null ||                 am start --display $displayId --user current -n '$comp' -f 0x18000000 2>/dev/null ||                 am start --display $displayId --user current -n '$comp' -f 0x10000000
                """.trimIndent()
            )
        }
    }

    fun refreshDpi() {
        val d = vd ?: return
        val w = texture.width.takeIf { it > 0 } ?: vdW
        val h = texture.height.takeIf { it > 0 } ?: vdH
        if (w <= 0 || h <= 0) return
        val targetDpi = effectiveDpi()
        runCatching {
            hostTexture?.setDefaultBufferSize(w, h)
            d.resize(w, h, targetDpi)
            vdW = w
            vdH = h
        }
    }

    private fun applyDisplaySize() {
        val d = vd ?: return
        val w = texture.width
        val h = texture.height
        if (w <= 0 || h <= 0 || (w == vdW && h == vdH)) return
        runCatching {
            hostTexture?.setDefaultBufferSize(w, h)
            d.resize(w, h, effectiveDpi())
            vdW = w
            vdH = h
        }
    }

    private fun forwardTouch(e: MotionEvent) {
        val svc = ShizukuManager.currentService() ?: return
        if (displayId < 0 || texture.width == 0 || texture.height == 0) return

        val sx = vdW.toFloat() / texture.width
        val sy = vdH.toFloat() / texture.height

        val n = e.pointerCount
        val props = Array(n) { i ->
            MotionEvent.PointerProperties().also {
                e.getPointerProperties(i, it)
                it.toolType = MotionEvent.TOOL_TYPE_FINGER
            }
        }

        if (e.actionMasked == MotionEvent.ACTION_MOVE && e.historySize > 0) {
            for (h in 0 until e.historySize) {
                val histCoords = Array(n) { i ->
                    MotionEvent.PointerCoords().also {
                        e.getHistoricalPointerCoords(i, h, it)
                        it.x = (it.x * sx).coerceIn(0f, max(0f, vdW - 1f))
                        it.y = (it.y * sy).coerceIn(0f, max(0f, vdH - 1f))
                        it.pressure = 1f
                        it.size = 1f
                    }
                }
                val histEv = MotionEvent.obtain(
                    e.downTime,
                    e.getHistoricalEventTime(h),
                    MotionEvent.ACTION_MOVE,
                    n,
                    props,
                    histCoords,
                    e.metaState,
                    e.buttonState,
                    1f,
                    1f,
                    e.deviceId,
                    0,
                    InputDevice.SOURCE_TOUCHSCREEN,
                    0,
                )
                runCatching { svc.injectMotion(histEv, displayId) }
                histEv.recycle()
            }
        }

        val coords = Array(n) { i ->
            MotionEvent.PointerCoords().also {
                e.getPointerCoords(i, it)
                it.x = (it.x * sx).coerceIn(0f, max(0f, vdW - 1f))
                it.y = (it.y * sy).coerceIn(0f, max(0f, vdH - 1f))
                it.pressure = if (e.actionMasked == MotionEvent.ACTION_UP) 0f else 1f
                it.size = 1f
            }
        }

        val ev = MotionEvent.obtain(
            e.downTime,
            e.eventTime,
            e.action,
            n,
            props,
            coords,
            e.metaState,
            e.buttonState,
            1f,
            1f,
            e.deviceId,
            0,
            InputDevice.SOURCE_TOUCHSCREEN,
            0,
        )
        runCatching { svc.injectMotion(ev, displayId) }
        ev.recycle()
    }

    private fun sendKey(code: Int) {
        val svc = ShizukuManager.currentService() ?: return
        if (displayId < 0) return
        val t = SystemClock.uptimeMillis()
        for (action in intArrayOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
            val ev = KeyEvent(
                t, t, action, code, 0, 0,
                KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD,
            )
            runCatching { svc.injectKey(ev, displayId) }
        }
    }

    private fun animateAndClose(kill: Boolean) {
        if (closed || closingAnimated) return
        closingAnimated = true
        dismissPopupMenu()
        removeBubbleNow()
        anim?.cancel()
        root.animate().cancel()
        texture.setOnTouchListener(null)

        root.animate()
            .scaleX(0.72f)
            .scaleY(0.72f)
            .alpha(0f)
            .setDuration(220)
            .setInterpolator(DecelerateInterpolator(1.8f))
            .withEndAction {
                finalizeClose(kill)
            }
            .start()
    }

    fun close(kill: Boolean) {
        if (closed) return
        if (!closingAnimated && root.windowToken != null && !isBubble) {
            animateAndClose(kill)
            return
        }
        finalizeClose(kill)
    }

    private fun finalizeClose(kill: Boolean) {
        if (closed) return
        closed = true
        dismissPopupMenu()
        removeBubbleNow()
        runCatching {
            root.visibility = View.GONE
            wm.removeViewImmediate(root)
        }
        scope.launch {
            if (kill) ShizukuManager.exec("am force-stop $pkg")
            release()
            onClosed(this@FloatWindow)
        }
    }

    fun destroyNow() {
        if (closed) return
        closed = true
        dismissPopupMenu()
        removeBubbleNow()
        anim?.cancel()
        root.animate().cancel()
        runCatching { wm.removeViewImmediate(root) }
        release()
    }

    private fun release() {
        runCatching { vd?.release() }
        vd = null
        runCatching { surface?.release() }
        surface = null
        displayId = -1
    }

    private class DotsView(context: Context) : View(context) {
        private val d = context.resources.displayMetrics.density
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCCFFFFFF.toInt() }
        override fun onDraw(canvas: Canvas) {
            val cy = height / 2f
            val r = 1.85f * d
            for (i in -1..1) canvas.drawCircle(width / 2f + i * 8.5f * d, cy, r, paint)
        }
    }

    private class ArcView(context: Context, private val left: Boolean) : View(context) {
        private val d = context.resources.displayMetrics.density
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCCB8B8C4.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3f * d
            strokeCap = Paint.Cap.ROUND
        }
        private val rect = RectF()
        override fun onDraw(canvas: Canvas) {
            val m = 4f * d
            val r = 18f * d
            val cx = if (left) m + r else width - m - r
            val cy = height - m - r
            rect.set(cx - r, cy - r, cx + r, cy + r)
            canvas.drawArc(rect, if (left) 98f else 10f, 72f, false, paint)
        }
    }

    private class IconView(context: Context, kind: Int) : View(context) {
        companion object {
            const val BACK = 0
            const val FULLSCREEN = 1
            const val EXIT_FULLSCREEN = 2
        }

        var kind: Int = kind
            set(v) { field = v; invalidate() }
        private val d = context.resources.displayMetrics.density
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 1.8f * d
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val path = Path()

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            canvas.drawCircle(w / 2, h / 2, min(w, h) / 2, bg)
            path.reset()
            when (kind) {
                BACK -> {
                    path.moveTo(w * 0.58f, h * 0.28f)
                    path.lineTo(w * 0.40f, h * 0.50f)
                    path.lineTo(w * 0.58f, h * 0.72f)
                }

                else -> {
                    val a = 0.30f
                    val b = 0.70f
                    val l = 0.17f
                    if (kind == FULLSCREEN) {
                        corner(w, h, a, a, +l, +l)
                        corner(w, h, b, a, -l, +l)
                        corner(w, h, a, b, +l, -l)
                        corner(w, h, b, b, -l, -l)
                    } else {
                        corner(w, h, a + l, a + l, -l, -l)
                        corner(w, h, b - l, a + l, +l, -l)
                        corner(w, h, a + l, b - l, -l, +l)
                        corner(w, h, b - l, b - l, +l, +l)
                    }
                }
            }
            canvas.drawPath(path, stroke)
        }

        private fun corner(w: Float, h: Float, x: Float, y: Float, dx: Float, dy: Float) {
            path.moveTo(w * (x + dx), h * y)
            path.lineTo(w * x, h * y)
            path.lineTo(w * x, h * (y + dy))
        }
    }
}
