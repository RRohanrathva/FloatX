package com.floatx.app.shizuku

import android.content.Context
import kotlin.system.exitProcess

/**
 * Runs inside the Shizuku server process with shell (or root) privileges.
 * Shizuku instantiates it with either a no-arg or a Context constructor.
 */
class UserService() : IUserService.Stub() {

    @Suppress("unused")
    constructor(context: Context) : this()

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().readText()
            process.waitFor()
            output
        } catch (t: Throwable) {
            "Error: ${t.message}"
        }
    }
}
