package com.floatx.app.window

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.SystemClock
import android.view.Gravity
import android.view.GestureDetector
import android.view.InputDevice
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.floatx.app.data.Prefs
import com.floatx.app.shizuku.ShizukuManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

/**
 * One floating app window.
 *
 * The app runs on a private VirtualDisplay that renders into a TextureView inside our own
 * overlay window. Because the window is ours, we control move / resize / maximize / close
 * and all animations. Touch is forwarded to the virtual display through the Shizuku service.
 */
@SuppressLint("ClickableViewAccessibility")
class FloatWindow(
    private val ctx: Context,
    private val wm: WindowManager,
    private val pkg: String,
    private val scope: CoroutineScope,
    private val index: Int,
    private val onClosed: (FloatWindow) -> Unit,
) {
    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private val screenW get() = wm.maximumWindowMetrics.bounds.width()
    private val screenH get() = wm.maximumWindowMetrics.bounds.height()

    // Thin strips above / below the app picture (drag area and gesture area).
    private val topH = dp(26)
    private val botH = dp(36)
    private val minW = dp(260)
    private val minH = dp(360)
    private val minScale = 0.45f
    private val baseCorner = dp(28).toFloat()

    private lateinit var root: FrameLayout
    /** Holds EVERYTHING (app picture + handle + buttons + corners). Scaled as one piece. */
    private lateinit var container: FrameLayout
    private lateinit var texture: TextureView
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var cornerLeft: View
    private lateinit var cornerRight: View
    private lateinit var fsIcon: IconView

    // Logical (unscaled) size of the container. The window on screen is this size * scale.
    private var baseW = 0
    private var baseH = 0
    private var cw = 0
    private var ch = 0

    private var cornerPx = baseCorner
    private var hostTexture: SurfaceTexture? = null
    private var surface: Surface? = null
    private var vd: VirtualDisplay? = null
    private var displayId = -1
    private var vdW = 0
    private var vdH = 0
    private var maximized = false
    private var restore = Rect()
    private var closed = false
    private var anim: ValueAnimator? = null

    private val component: String? =
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToString()

    // ------------------------------------------------------------------ show

    fun show() {
        val pct = Prefs.windowPercent / 100f
        val base = (min(screenW, screenH) * pct).toInt()
        val w: Int
        val h: Int
        if (screenW <= screenH) {
            w = base
            h = (base * 1.5f).toInt().plus(topH + botH).coerceAtMost((screenH * 0.85f).toInt())
        } else {
            h = base
            w = (base * 1.4f).toInt().coerceAtMost((screenW * 0.85f).toInt())
        }
        baseW = w.coerceAtLeast(minW)
        baseH = h.coerceAtLeast(minH)
        cw = baseW
        ch = baseH

        buildUi()

        val off = (index % 5) * dp(26)
        lp = WindowManager.LayoutParams(
            baseW,
            baseH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = ((screenW - width) / 2 + off).coerceAtLeast(0)
            y = ((screenH - height) / 2 + off).coerceAtLeast(0)
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }

        root.scaleX = 0.8f
        root.scaleY = 0.8f
        root.alpha = 0f
        wm.addView(root, lp)
        root.animate()
            .scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(380)
            .setInterpolator(OvershootInterpolator(1.1f))
            .start()
    }

    // -------------------------------------------------------------------- UI

    private fun buildUi() {
        root = FrameLayout(ctx).apply {
            background = GradientDrawable().apply { setColor(0xFF0E0D14.toInt()) }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, cornerPx)
                }
            }
            addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
                v.pivotX = v.width / 2f
                v.pivotY = v.height / 2f
                v.invalidateOutline()
            }
        }

        container = FrameLayout(ctx).apply {
            pivotX = 0f
            pivotY = 0f
        }
        root.addView(container, FrameLayout.LayoutParams(cw, ch))

        texture = TextureView(ctx).apply {
            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                    hostTexture = st
                    createDisplay(width, height)
                }

                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
            setOnTouchListener { _, e ->
                forwardTouch(e)
                true
            }
        }

        val column = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(buildTopBar(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, topH))
            addView(texture, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(buildBottomBar(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, botH))
        }
        container.addView(
            column,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )

        // Resize corners (bottom-left / bottom-right)
        cornerLeft = ArcView(ctx, left = true)
        cornerRight = ArcView(ctx, left = false)
        container.addView(cornerLeft, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM or Gravity.START))
        container.addView(cornerRight, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM or Gravity.END))
        attachResize(cornerLeft, fromLeft = true)
        attachResize(cornerRight, fromLeft = false)
    }

    /** Top strip: press & hold the dots area and move to drag the window. */
    private fun buildTopBar(): FrameLayout {
        val bar = FrameLayout(ctx)
        bar.addView(DotsView(ctx), FrameLayout.LayoutParams(dp(30), dp(10), Gravity.CENTER))
        attachDrag(bar)
        return bar
    }

    /** Bottom strip: [fullscreen]  ——swipe-up pill——  [back] */
    private fun buildBottomBar(): LinearLayout {
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(View(ctx), LinearLayout.LayoutParams(dp(36), 1))

        fsIcon = IconView(ctx, IconView.FULLSCREEN).apply { setOnClickListener { toggleMaximize() } }
        bar.addView(fsIcon, LinearLayout.LayoutParams(dp(26), dp(26)).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })

        val swipe = FrameLayout(ctx)
        val pill = View(ctx).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(2).toFloat()
                setColor(0xCCFFFFFF.toInt())
            }
        }
        swipe.addView(pill, FrameLayout.LayoutParams(dp(60), dp(4), Gravity.CENTER))
        attachSwipeClose(swipe)
        bar.addView(swipe, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        val back = IconView(ctx, IconView.BACK).apply { setOnClickListener { sendKey(KeyEvent.KEYCODE_BACK) } }
        bar.addView(back, LinearLayout.LayoutParams(dp(26), dp(26)).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })
        bar.addView(View(ctx), LinearLayout.LayoutParams(dp(36), 1))
        return bar
    }

    // --------------------------------------------------------------- gestures

    /** Move the window by dragging the top strip. */
    private fun attachDrag(bar: View) {
        var startRawX = 0f
        var startRawY = 0f
        var startX = 0
        var startY = 0
        var restoredByDrag = false

        bar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    restoredByDrag = false
                    root.animate().cancel()
                    root.animate().alpha(0.92f).setDuration(120).start()
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    if (maximized) {
                        // Pull down on the top strip to leave fullscreen
                        if (!restoredByDrag && dy > dp(90)) {
                            restoredByDrag = true
                            toggleMaximize()
                        }
                    } else {
                        lp.x = (startX + dx).toInt().coerceIn(-lp.width + dp(90), screenW - dp(90))
                        lp.y = (startY + dy).toInt().coerceIn(0, screenH - topH)
                        updateLayout()
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    root.animate().alpha(1f).setDuration(160).start()
            }
            true
        }
    }

    /** Swipe up on the bottom pill to close the window (and stop the app). */
    private fun attachSwipeClose(zone: View) {
        var startRawY = 0f
        var startY = 0
        zone.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    anim?.cancel()
                    root.animate().cancel()
                    startRawY = e.rawY
                    startY = lp.y
                }

                MotionEvent.ACTION_MOVE -> {
                    val dy = min(0f, e.rawY - startRawY)
                    lp.y = (startY + dy).toInt()
                    root.alpha = (1f + dy / (lp.height * 0.7f)).coerceIn(0.25f, 1f)
                    updateLayout()
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dy = e.rawY - startRawY
                    if (e.actionMasked == MotionEvent.ACTION_UP && dy < -max(dp(80), (lp.height * 0.2f).toInt())) {
                        close(kill = true)
                    } else {
                        val from = lp.y
                        anim?.cancel()
                        anim = ValueAnimator.ofFloat(0f, 1f).apply {
                            duration = 200
                            interpolator = DecelerateInterpolator()
                            addUpdateListener { a ->
                                val t = a.animatedValue as Float
                                lp.y = (from + (startY - from) * t).toInt()
                                updateLayout()
                            }
                            start()
                        }
                        root.animate().alpha(1f).setDuration(200).start()
                    }
                }
            }
            true
        }
    }

    /**
     * Resize from a bottom corner. The whole window (picture, handle, buttons, corners) is
     * scaled uniformly, so the proportions never change. The opposite edge stays in place.
     */
    private fun attachResize(handle: View, fromLeft: Boolean) {
        var startRawX = 0f
        var startRawY = 0f
        var startX = 0
        var startW = 1
        var startH = 1
        handle.setOnTouchListener { _, e ->
            if (maximized) return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    anim?.cancel()
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = lp.x
                    startW = lp.width.coerceAtLeast(1)
                    startH = lp.height.coerceAtLeast(1)
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    val kx = (if (fromLeft) -dx else dx) / startW
                    val ky = dy / startH
                    val startS = startW.toFloat() / cw
                    val availW = if (fromLeft) startX + startW else screenW - startX
                    val availH = screenH - lp.y
                    val maxS = max(minScale, min(availW.toFloat() / cw, availH.toFloat() / ch))
                    val s = (startS * (1f + (kx + ky) / 2f)).coerceIn(minScale, maxS)
                    val nw = (cw * s).toInt()
                    val nh = (ch * s).toInt()
                    lp.width = nw
                    lp.height = nh
                    if (fromLeft) lp.x = startX + startW - nw
                    cornerPx = baseCorner * s
                    applyWindow()
                }
            }
            true
        }
    }

    /** Push lp (window size) into the container scale so content always fills the window. */
    private fun applyWindow() {
        container.scaleX = lp.width.toFloat() / cw
        container.scaleY = lp.height.toFloat() / ch
        root.invalidateOutline()
        updateLayout()
    }

    private fun updateLayout() {
        if (!closed) runCatching { wm.updateViewLayout(root, lp) }
    }

    // ------------------------------------------------------------- maximize

    private fun statusBarHeight(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun toggleMaximize() {
        if (closed) return
        val to: Rect
        val toCorner: Float
        if (!maximized) {
            restore = Rect(lp.x, lp.y, lp.x + lp.width, lp.y + lp.height)
            to = Rect(0, 0, screenW, screenH)
            toCorner = 0f
            cw = screenW
            ch = screenH
            container.setPadding(0, statusBarHeight(), 0, 0)
            maximized = true
        } else {
            to = Rect(restore)
            toCorner = baseCorner * (restore.width().toFloat() / baseW)
            cw = baseW
            ch = baseH
            container.setPadding(0, 0, 0, 0)
            maximized = false
        }
        container.layoutParams = FrameLayout.LayoutParams(cw, ch)
        val vis = if (maximized) View.GONE else View.VISIBLE
        cornerLeft.visibility = vis
        cornerRight.visibility = vis
        fsIcon.kind = if (maximized) IconView.EXIT_FULLSCREEN else IconView.FULLSCREEN

        val fx = lp.x
        val fy = lp.y
        val fw = lp.width
        val fh = lp.height
        val fc = cornerPx
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 340
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                lp.x = (fx + (to.left - fx) * t).toInt()
                lp.y = (fy + (to.top - fy) * t).toInt()
                lp.width = (fw + (to.width() - fw) * t).toInt().coerceAtLeast(1)
                lp.height = (fh + (to.height() - fh) * t).toInt().coerceAtLeast(1)
                cornerPx = fc + (toCorner - fc) * t
                applyWindow()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    lp.x = to.left; lp.y = to.top
                    lp.width = to.width(); lp.height = to.height()
                    cornerPx = toCorner
                    applyWindow()
                    root.post { applyDisplaySize() }
                }
            })
            start()
        }
    }

    // ------------------------------------------------------- virtual display

    private fun createDisplay(w: Int, h: Int) {
        val st = hostTexture ?: return
        st.setDefaultBufferSize(w, h)
        val s = Surface(st)
        surface = s

        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val dpi = ctx.resources.displayMetrics.densityDpi
        val base = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
        val supportsTouch = 1 shl 6

        val display = try {
            dm.createVirtualDisplay("floatx-$pkg", w, h, dpi, s, base or supportsTouch)
        } catch (_: Throwable) {
            try {
                dm.createVirtualDisplay("floatx-$pkg", w, h, dpi, s, base)
            } catch (t: Throwable) {
                null
            }
        }
        if (display == null) {
            android.widget.Toast.makeText(ctx, "This device blocked the floating display", android.widget.Toast.LENGTH_LONG).show()
            close(kill = false)
            return
        }
        vd = display
        vdW = w
        vdH = h
        displayId = display.display.displayId

        val comp = component
        if (comp == null) {
            close(kill = false)
            return
        }
        scope.launch {
            ShizukuManager.exec(
                """
                settings put global force_resizable_activities 1
                settings put global enable_freeform_support 1
                am start --display $displayId --user current -n '$comp' -f 0x10000000
                """.trimIndent()
            )
        }
    }

    /** Make the virtual display match the visible area (crisp redraw after resize). */
    private fun applyDisplaySize() {
        val d = vd ?: return
        val w = texture.width
        val h = texture.height
        if (w <= 0 || h <= 0 || (w == vdW && h == vdH)) return
        runCatching {
            hostTexture?.setDefaultBufferSize(w, h)
            d.resize(w, h, ctx.resources.displayMetrics.densityDpi)
            vdW = w
            vdH = h
        }
    }

    // ---------------------------------------------------------------- input

    private fun forwardTouch(e: MotionEvent) {
        val svc = ShizukuManager.currentService() ?: return
        if (displayId < 0 || texture.width == 0 || texture.height == 0) return

        val sx = vdW.toFloat() / texture.width
        val sy = vdH.toFloat() / texture.height
        val n = e.pointerCount
        val props = Array(n) { i -> MotionEvent.PointerProperties().also { e.getPointerProperties(i, it) } }
        val coords = Array(n) { i ->
            MotionEvent.PointerCoords().also {
                e.getPointerCoords(i, it)
                it.x *= sx
                it.y *= sy
            }
        }
        val ev = MotionEvent.obtain(
            e.downTime, e.eventTime, e.action, n, props, coords,
            e.metaState, e.buttonState, 1f, 1f, e.deviceId, e.edgeFlags,
            InputDevice.SOURCE_TOUCHSCREEN, e.flags,
        )
        runCatching { svc.injectMotion(ev, displayId) }
        ev.recycle()
    }

    private fun sendKey(code: Int) {
        val svc = ShizukuManager.currentService() ?: return
        if (displayId < 0) return
        val t = SystemClock.uptimeMillis()
        for (action in intArrayOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
            val ev = KeyEvent(
                t, t, action, code, 0, 0,
                KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD,
            )
            runCatching { svc.injectKey(ev, displayId) }
        }
    }

    // ---------------------------------------------------------------- close

    // ---------------------------------------------------------------- close

    fun close(kill: Boolean) {
        if (closed) return
        closed = true
        anim?.cancel()
        root.animate().cancel()
        root.animate()
            .scaleX(0.8f).scaleY(0.8f).alpha(0f)
            .setDuration(200)
            .withEndAction { runCatching { wm.removeView(root) } }
            .start()
        scope.launch {
            if (kill) ShizukuManager.exec("am force-stop $pkg")
            release()
            onClosed(this@FloatWindow)
        }
    }

    /** Immediate teardown (service is going away). */
    fun destroyNow() {
        if (closed) return
        closed = true
        anim?.cancel()
        runCatching { wm.removeView(root) }
        release()
    }

    private fun release() {
        runCatching { vd?.release() }
        vd = null
        runCatching { surface?.release() }
        surface = null
        displayId = -1
    }

    // ------------------------------------------------------------ custom views

    /** Three small dots = drag handle. */
    private class DotsView(context: Context) : View(context) {
        private val d = context.resources.displayMetrics.density
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAAFFFFFF.toInt() }
        override fun onDraw(canvas: Canvas) {
            val cy = height / 2f
            val r = 1.7f * d
            for (i in -1..1) canvas.drawCircle(width / 2f + i * 8f * d, cy, r, paint)
        }
    }

    /** Grey quarter-circle arc shown in the bottom corners = resize handle. */
    private class ArcView(context: Context, private val left: Boolean) : View(context) {
        private val d = context.resources.displayMetrics.density
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCCB8B8C4.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3f * d
            strokeCap = Paint.Cap.ROUND
        }
        private val rect = RectF()
        override fun onDraw(canvas: Canvas) {
            val m = 4f * d
            val r = 18f * d
            val cx = if (left) m + r else width - m - r
            val cy = height - m - r
            rect.set(cx - r, cy - r, cx + r, cy + r)
            canvas.drawArc(rect, if (left) 98f else 10f, 72f, false, paint)
        }
    }

    /** Round button with a drawn icon (so it scales perfectly with the window). */
    private class IconView(context: Context, kind: Int) : View(context) {
        companion object {
            const val BACK = 0
            const val FULLSCREEN = 1
            const val EXIT_FULLSCREEN = 2
        }

        var kind: Int = kind
            set(v) { field = v; invalidate() }
        private val d = context.resources.displayMetrics.density
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 1.8f * d
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val path = Path()

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            canvas.drawCircle(w / 2, h / 2, min(w, h) / 2, bg)
            path.reset()
            when (kind) {
                BACK -> {
                    path.moveTo(w * 0.58f, h * 0.28f)
                    path.lineTo(w * 0.40f, h * 0.50f)
                    path.lineTo(w * 0.58f, h * 0.72f)
                }

                else -> {
                    val a = 0.30f
                    val b = 0.70f
                    val l = 0.17f
                    if (kind == FULLSCREEN) {
                        // corners pointing outwards
                        corner(w, h, a, a, +l, +l)
                        corner(w, h, b, a, -l, +l)
                        corner(w, h, a, b, +l, -l)
                        corner(w, h, b, b, -l, -l)
                    } else {
                        // corners pointing inwards
                        corner(w, h, a + l, a + l, -l, -l)
                        corner(w, h, b - l, a + l, +l, -l)
                        corner(w, h, a + l, b - l, -l, +l)
                        corner(w, h, b - l, b - l, +l, +l)
                    }
                }
            }
            canvas.drawPath(path, stroke)
        }

        private fun corner(w: Float, h: Float, x: Float, y: Float, dx: Float, dy: Float) {
            path.moveTo(w * (x + dx), h * y)
            path.lineTo(w * x, h * y)
            path.lineTo(w * x, h * (y + dy))
        }
    }
}
