package com.floatx.app.shizuku

import android.content.Context
import com.floatx.app.data.Prefs

/**
 * Launches an app in a freeform (floating) window.
 *
 * Works on Android 11 - 17 by running `am start --windowingMode 5` as the Shizuku user
 * and then resizing the new task to a centered window.
 */
object FreeformLauncher {

    private const val WINDOWING_MODE_FREEFORM = 5

    suspend fun launch(context: Context, pkg: String): Result<Unit> {
        val component = context.packageManager.getLaunchIntentForPackage(pkg)?.component
            ?: return Result.failure(IllegalStateException("Can't open this app"))

        val dm = context.resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val pct = Prefs.windowPercent / 100f

        val w: Int
        val h: Int
        if (sw <= sh) {
            w = (sw * pct).toInt()
            h = (w * 1.5f).toInt().coerceAtMost((sh * 0.85f).toInt())
        } else {
            h = (sh * pct).toInt()
            w = (h * 1.5f).toInt().coerceAtMost((sw * 0.85f).toInt())
        }
        val left = (sw - w) / 2
        val top = (sh - h) / 2
        val right = left + w
        val bottom = top + h

        val comp = component.flattenToString()
        val script = """
            settings put global enable_freeform_support 1
            settings put global force_resizable_activities 1
            settings put global freeform_window_management 1
            am start --user current -n '$comp' --windowingMode $WINDOWING_MODE_FREEFORM
            sleep 0.7
            T=${'$'}(dumpsys activity activities | grep -m1 -E 'topResumedActivity|ResumedActivity' | grep -oE ' t[0-9]+[ }]' | grep -oE '[0-9]+' | head -n1)
            if [ -n "${'$'}T" ]; then
              cmd activity task resize ${'$'}T $left $top $right $bottom >/dev/null 2>&1 || am task resize ${'$'}T $left $top $right $bottom >/dev/null 2>&1
            fi
        """.trimIndent()

        val out = ShizukuManager.exec(script)
            ?: return Result.failure(IllegalStateException("Shizuku isn't ready. Start it and grant permission."))

        val failed = out.contains("Error:", ignoreCase = true) || out.contains("Exception", ignoreCase = true)
        return if (failed) {
            Result.failure(IllegalStateException(out.lines().firstOrNull { it.isNotBlank() } ?: "Launch failed"))
        } else {
            Result.success(Unit)
        }
    }
}
