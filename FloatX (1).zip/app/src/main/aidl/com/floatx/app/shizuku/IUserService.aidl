package com.floatx.app.shizuku;

interface IUserService {
    // Reserved destroy transaction used by Shizuku.
    void destroy() = 16777114;

    // Runs a shell command as the Shizuku user (shell / root) and returns its output.
    String exec(String command) = 1;
}
