# FloatX

Open any app in a **floating (freeform) window** on Android 11 – 17, using **Shizuku**.
Material 3 Expressive UI, plus an edge sidebar: swipe from the screen edge, pick an app, it opens floating.

## Build the APK on GitHub
1. Create a new GitHub repo and upload everything from this folder (including the hidden `.github` folder).
2. Open the **Actions** tab → **Build APK** → wait for the green tick.
3. Download the `FloatX-apk` artifact from the run page, unzip, install `FloatX.apk`.

Tip: push a tag like `v1.0` and the APK is also attached to a GitHub Release.

## First-time setup on the phone
1. Install and start **Shizuku** (Wireless debugging, or root).
2. Open FloatX → tap **Grant** to allow it in Shizuku.
3. Tap **Allow** for "display over other apps".
4. Turn on **Edge sidebar**.

## Use
- **Apps tab:** tap an app → opens floating. Star apps to pin them in the sidebar.
- **Sidebar:** swipe the pill on the screen edge (or tap it) → app grid → tap an app.
- **Home tab:** choose Left/Right edge and window size.

## How it works
`FreeformLauncher` runs, through a Shizuku user service (shell privileges):

```
settings put global enable_freeform_support 1
settings put global force_resizable_activities 1
settings put global freeform_window_management 1
am start --user current -n <component> --windowingMode 5
cmd activity task resize <taskId> l t r b
```

## Notes
- Some ROMs need a reboot once after freeform support is switched on.
- Some apps refuse to be resized; that is an app/ROM limitation.
- Min SDK 30 (Android 11), target SDK 35, compile SDK 36, AGP 8.9.1, Kotlin 2.2.0, Compose Material3 1.4.0.
