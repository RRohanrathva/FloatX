package com.floatx.app.shizuku

import android.content.Context
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.lang.reflect.Method
import kotlin.system.exitProcess

/**
 * Runs inside the Shizuku server process with shell (or root) privileges.
 * Shizuku instantiates it with either a no-arg or a Context constructor.
 */
class UserService() : IUserService.Stub() {

    init {
        runCatching { HiddenApiBypass.addHiddenApiExemptions("L") }
    }

    private val setDisplayId: Method? = runCatching {
        InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType)
    }.getOrNull()

    private val injector: ((InputEvent) -> Unit)? = resolveInjector()

    @Suppress("unused")
    constructor(context: Context) : this()

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().readText()
            process.waitFor()
            output
        } catch (t: Throwable) {
            "Error: ${t.message}"
        }
    }

    override fun injectMotion(event: MotionEvent, displayId: Int) {
        try {
            setDisplayId?.invoke(event, displayId)
            injector?.invoke(event)
        } catch (_: Throwable) {
        } finally {
            runCatching { event.recycle() }
        }
    }

    override fun injectKey(event: KeyEvent, displayId: Int) {
        try {
            setDisplayId?.invoke(event, displayId)
            injector?.invoke(event)
        } catch (_: Throwable) {
        }
    }

    /** Finds InputManager(Global).injectInputEvent for whatever Android version we run on. */
    private fun resolveInjector(): ((InputEvent) -> Unit)? {
        val classNames = listOf(
            "android.hardware.input.InputManagerGlobal", // Android 14+
            "android.hardware.input.InputManager",
        )
        for (name in classNames) {
            try {
                val cls = Class.forName(name)
                val inst = cls.getMethod("getInstance").invoke(null) ?: continue
                val methods = cls.methods.filter { it.name == "injectInputEvent" }
                val m2 = methods.firstOrNull { it.parameterTypes.size == 2 }
                val m3 = methods.firstOrNull { it.parameterTypes.size == 3 }
                if (m2 != null) return { ev -> m2.invoke(inst, ev, 0) }
                if (m3 != null) return { ev -> m3.invoke(inst, ev, 0, -1) }
            } catch (_: Throwable) {
            }
        }
        return null
    }
}
