package com.floatx.app.window

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.floatx.app.MainActivity
import com.floatx.app.R
import com.floatx.app.shizuku.ShizukuManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Foreground service that owns all floating windows. Stops itself when the last one closes. */
class FloatHostService : Service() {

    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val windows = mutableListOf<FloatWindow>()
    private var counter = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pkg = intent?.getStringExtra(EXTRA_PKG)
        if (pkg == null) {
            stopIfIdle()
            return START_NOT_STICKY
        }
        scope.launch {
            if (!Settings.canDrawOverlays(this@FloatHostService)) {
                toast("Allow display over other apps first")
                stopIfIdle()
                return@launch
            }
            // Makes sure Shizuku is running, permitted and its service is bound.
            if (ShizukuManager.exec("true") == null) {
                toast("Start Shizuku and grant permission to FloatX")
                stopIfIdle()
                return@launch
            }
            val window = FloatWindow(this@FloatHostService, wm, pkg, scope, counter++) { w ->
                windows.remove(w)
                stopIfIdle()
            }
            windows.add(window)
            runCatching { window.show() }.onFailure {
                windows.remove(window)
                toast("Couldn't open window: ${it.message}")
                stopIfIdle()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        windows.toList().forEach { it.destroyNow() }
        windows.clear()
        scope.cancel()
        super.onDestroy()
    }

    private fun stopIfIdle() {
        if (windows.isEmpty()) stopSelf()
    }

    private fun toast(msg: String) = Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Floating windows", NotificationManager.IMPORTANCE_MIN)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_float)
            .setContentTitle("Floating windows are open")
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    companion object {
        private const val CHANNEL_ID = "floatx_windows"
        private const val NOTIF_ID = 43
        private const val EXTRA_PKG = "pkg"

        /** Open [pkg] in a new floating window. */
        fun open(context: Context, pkg: String) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, FloatHostService::class.java).putExtra(EXTRA_PKG, pkg),
            )
        }
    }
}
