package com.floatx.app.data

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        sp = context.applicationContext.getSharedPreferences("floatx", Context.MODE_PRIVATE)
    }

    var sidebarEnabled: Boolean
        get() = sp.getBoolean("sidebar", false)
        set(v) = sp.edit().putBoolean("sidebar", v).apply()

    /** true = sidebar handle on the right edge, false = left edge */
    var rightSide: Boolean
        get() = sp.getBoolean("right_side", true)
        set(v) = sp.edit().putBoolean("right_side", v).apply()

    /** Floating window size, percent of the screen (50..95) */
    var windowPercent: Int
        get() = sp.getInt("window_percent", 75)
        set(v) = sp.edit().putInt("window_percent", v.coerceIn(50, 95)).apply()

    var pinned: Set<String>
        get() = HashSet(sp.getStringSet("pinned", emptySet()) ?: emptySet())
        set(v) = sp.edit().putStringSet("pinned", HashSet(v)).apply()
}
