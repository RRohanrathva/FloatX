package com.floatx.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableIntStateOf
import androidx.core.content.ContextCompat
import com.floatx.app.data.Prefs
import com.floatx.app.shizuku.ShizukuManager
import com.floatx.app.sidebar.SidebarService
import com.floatx.app.ui.AppRoot
import com.floatx.app.ui.FloatXTheme
import com.floatx.app.ui.RootActions

class MainActivity : ComponentActivity() {

    private val resumeTick = mutableIntStateOf(0)

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Sidebar works with or without the notification being visible.
            SidebarService.start(this)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val actions = RootActions(
            openShizuku = { ShizukuManager.openShizuku(this) },
            requestShizukuPermission = { ShizukuManager.requestPermission(this) },
            requestOverlay = {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            },
            toggleSidebar = { on -> setSidebar(on) },
            sideChanged = {
                if (Prefs.sidebarEnabled && Settings.canDrawOverlays(this)) SidebarService.refresh(this)
            },
        )

        setContent {
            FloatXTheme {
                AppRoot(resumeTick.intValue, actions)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
        ShizukuManager.refresh()
        if (Prefs.sidebarEnabled && Settings.canDrawOverlays(this)) {
            runCatching { SidebarService.start(this) }
        }
    }

    private fun setSidebar(on: Boolean) {
        Prefs.sidebarEnabled = on
        if (!on) {
            SidebarService.stop(this)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow display over other apps first", Toast.LENGTH_SHORT).show()
            return
        }
        val needsNotifPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsNotifPermission) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            SidebarService.start(this)
        }
    }
}
