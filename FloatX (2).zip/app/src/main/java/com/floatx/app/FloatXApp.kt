package com.floatx.app

import android.app.Application
import com.floatx.app.data.Prefs
import com.floatx.app.shizuku.ShizukuManager

class FloatXApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        ShizukuManager.init(this)
    }
}
