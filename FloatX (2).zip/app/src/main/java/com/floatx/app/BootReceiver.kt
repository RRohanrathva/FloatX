package com.floatx.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.floatx.app.data.Prefs
import com.floatx.app.sidebar.SidebarService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (Prefs.sidebarEnabled && Settings.canDrawOverlays(context)) {
            runCatching { SidebarService.start(context) }
        }
    }
}
