package com.floatx.app.sidebar

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs

/**
 * Thin pill on the screen edge. Swipe it towards the center (or tap it) to open the app list.
 */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class HandleView(
    context: Context,
    private val rightSide: Boolean,
    private val onOpen: () -> Unit,
) : View(context) {

    private val density = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xD96750A4.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99FFFFFF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
    }
    private val rect = RectF()
    private var downX = 0f
    private var opened = false

    override fun onDraw(canvas: Canvas) {
        val pillW = 5f * density
        val margin = 3f * density
        val left = if (rightSide) width - pillW - margin else margin
        rect.set(left, height * 0.18f, left + pillW, height * 0.82f)
        val r = pillW / 2f
        canvas.drawRoundRect(rect, r, r, fill)
        canvas.drawRoundRect(rect, r, r, stroke)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        // Keep the system back-gesture from stealing our edge swipe.
        systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                opened = false
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val towardCenter = if (rightSide) -dx else dx
                if (!opened && towardCenter > slop * 2) {
                    opened = true
                    performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    onOpen()
                }
            }

            MotionEvent.ACTION_UP -> {
                if (!opened && abs(e.rawX - downX) < slop) {
                    performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    onOpen()
                }
            }
        }
        return true
    }
}
