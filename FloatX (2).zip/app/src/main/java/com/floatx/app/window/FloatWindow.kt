package com.floatx.app.window

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.SystemClock
import android.view.Gravity
import android.view.GestureDetector
import android.view.InputDevice
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.floatx.app.data.Prefs
import com.floatx.app.shizuku.ShizukuManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.min

/**
 * One floating app window.
 *
 * The app runs on a private VirtualDisplay that renders into a TextureView inside our own
 * overlay window. Because the window is ours, we control move / resize / maximize / close
 * and all animations. Touch is forwarded to the virtual display through the Shizuku service.
 */
@SuppressLint("ClickableViewAccessibility")
class FloatWindow(
    private val ctx: Context,
    private val wm: WindowManager,
    private val pkg: String,
    private val scope: CoroutineScope,
    private val index: Int,
    private val onClosed: (FloatWindow) -> Unit,
) {
    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private val screenW get() = wm.maximumWindowMetrics.bounds.width()
    private val screenH get() = wm.maximumWindowMetrics.bounds.height()

    private val barH = dp(40)
    private val minW = dp(220)
    private val minH = dp(320)

    private lateinit var root: FrameLayout
    private lateinit var texture: TextureView
    private lateinit var lp: WindowManager.LayoutParams

    private var cornerPx = dp(28).toFloat()
    private var surfaceTexture: SurfaceTexture? = null
    private var surface: Surface? = null
    private var vd: VirtualDisplay? = null
    private var displayId = -1
    private var vdW = 0
    private var vdH = 0
    private var maximized = false
    private var restore = Rect()
    private var closed = false
    private var anim: ValueAnimator? = null

    private val component: String? =
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToString()

    // ------------------------------------------------------------------ show

    fun show() {
        buildUi()

        val pct = Prefs.windowPercent / 100f
        val base = (min(screenW, screenH) * pct).toInt()
        val w: Int
        val h: Int
        if (screenW <= screenH) {
            w = base
            h = (base * 1.5f).toInt().plus(barH).coerceAtMost((screenH * 0.85f).toInt())
        } else {
            h = base
            w = (base * 1.4f).toInt().coerceAtMost((screenW * 0.85f).toInt())
        }
        val off = (index % 5) * dp(26)

        lp = WindowManager.LayoutParams(
            w.coerceAtLeast(minW),
            h.coerceAtLeast(minH),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenW - width) / 2 + off
            y = (screenH - height) / 2 + off
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }

        root.scaleX = 0.8f
        root.scaleY = 0.8f
        root.alpha = 0f
        wm.addView(root, lp)
        root.animate()
            .scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(380)
            .setInterpolator(OvershootInterpolator(1.1f))
            .start()
    }

    // -------------------------------------------------------------------- UI

    private fun buildUi() {
        root = FrameLayout(ctx).apply {
            background = GradientDrawable().apply { setColor(0xFF0E0D14.toInt()) }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, cornerPx)
                }
            }
            addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
                v.pivotX = v.width / 2f
                v.pivotY = v.height / 2f
                v.invalidateOutline()
            }
        }

        texture = TextureView(ctx).apply {
            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                    surfaceTexture = st
                    createDisplay(width, height)
                }

                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
            setOnTouchListener { _, e ->
                forwardTouch(e)
                true
            }
        }

        val bar = buildBar()

        val column = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, barH))
            addView(texture, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        root.addView(
            column,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )

        val grip = GripView(ctx)
        root.addView(grip, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.BOTTOM or Gravity.END))
        attachResize(grip)
    }

    private fun buildBar(): FrameLayout {
        val bar = FrameLayout(ctx).apply { setBackgroundColor(0xFF211F2E.toInt()) }

        val pill = View(ctx).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(2).toFloat()
                setColor(0x66FFFFFF)
            }
        }
        bar.addView(pill, FrameLayout.LayoutParams(dp(44), dp(4), Gravity.CENTER))

        val left = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, 0, 0)
            addView(circleButton("×", 0xFFE5534B.toInt()) { close(kill = true) })
        }
        val right = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, dp(8), 0)
            addView(circleButton("‹", 0xFF3A3750.toInt()) { sendKey(KeyEvent.KEYCODE_BACK) })
            addView(circleButton("↗", 0xFF3A3750.toInt()) { popOut() })
            addView(circleButton("□", 0xFF5B4FD1.toInt()) { toggleMaximize() })
        }
        bar.addView(
            left,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START),
        )
        bar.addView(
            right,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END),
        )

        attachDrag(bar)
        return bar
    }

    private fun circleButton(label: String, color: Int, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
            }
            layoutParams = LinearLayout.LayoutParams(dp(28), dp(28)).apply {
                marginStart = dp(5)
                marginEnd = dp(5)
            }
            setOnClickListener { onClick() }
        }

    // --------------------------------------------------------------- gestures

    private fun attachDrag(bar: View) {
        val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                toggleMaximize()
                return true
            }
        })
        var startRawX = 0f
        var startRawY = 0f
        var startX = 0
        var startY = 0
        var restoredByDrag = false

        bar.setOnTouchListener { _, e ->
            detector.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    restoredByDrag = false
                    root.animate().cancel()
                    root.animate().alpha(0.92f).setDuration(120).start()
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    if (maximized) {
                        // Swipe down on the bar to leave fullscreen
                        if (!restoredByDrag && dy > dp(90)) {
                            restoredByDrag = true
                            toggleMaximize()
                        }
                    } else {
                        lp.x = (startX + dx).toInt().coerceIn(-lp.width + dp(90), screenW - dp(90))
                        lp.y = (startY + dy).toInt().coerceIn(0, screenH - barH)
                        updateLayout()
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    root.animate().alpha(1f).setDuration(160).start()
                    // Drag to the very top edge = fullscreen
                    if (e.actionMasked == MotionEvent.ACTION_UP && !maximized && e.rawY < dp(32)) {
                        toggleMaximize()
                    }
                }
            }
            true
        }
    }

    private fun attachResize(grip: View) {
        var startRawX = 0f
        var startRawY = 0f
        var startW = 0
        var startH = 0
        grip.setOnTouchListener { _, e ->
            if (maximized) return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startW = lp.width
                    startH = lp.height
                }

                MotionEvent.ACTION_MOVE -> {
                    lp.width = (startW + (e.rawX - startRawX)).toInt().coerceIn(minW, (screenW - lp.x).coerceAtLeast(minW))
                    lp.height = (startH + (e.rawY - startRawY)).toInt().coerceIn(minH, (screenH - lp.y).coerceAtLeast(minH))
                    updateLayout()
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> root.post { applyDisplaySize() }
            }
            true
        }
    }

    private fun updateLayout() {
        if (!closed) runCatching { wm.updateViewLayout(root, lp) }
    }

    // ------------------------------------------------------------- maximize

    private fun statusBarHeight(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun toggleMaximize() {
        if (closed) return
        val to: Rect
        val toCorner: Float
        val padTop: Int
        if (!maximized) {
            restore = Rect(lp.x, lp.y, lp.x + lp.width, lp.y + lp.height)
            to = Rect(0, 0, screenW, screenH)
            toCorner = 0f
            padTop = statusBarHeight()
            maximized = true
        } else {
            to = Rect(restore)
            toCorner = dp(28).toFloat()
            padTop = 0
            maximized = false
        }
        root.setPadding(0, padTop, 0, 0)

        val fx = lp.x
        val fy = lp.y
        val fw = lp.width
        val fh = lp.height
        val fc = cornerPx
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 340
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                lp.x = (fx + (to.left - fx) * t).toInt()
                lp.y = (fy + (to.top - fy) * t).toInt()
                lp.width = (fw + (to.width() - fw) * t).toInt()
                lp.height = (fh + (to.height() - fh) * t).toInt()
                cornerPx = fc + (toCorner - fc) * t
                root.invalidateOutline()
                updateLayout()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    root.post { applyDisplaySize() }
                }
            })
            start()
        }
    }

    // ------------------------------------------------------- virtual display

    private fun createDisplay(w: Int, h: Int) {
        val st = surfaceTexture ?: return
        st.setDefaultBufferSize(w, h)
        val s = Surface(st)
        surface = s

        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val dpi = ctx.resources.displayMetrics.densityDpi
        val base = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
        val supportsTouch = 1 shl 6

        val display = try {
            dm.createVirtualDisplay("floatx-$pkg", w, h, dpi, s, base or supportsTouch)
        } catch (_: Throwable) {
            try {
                dm.createVirtualDisplay("floatx-$pkg", w, h, dpi, s, base)
            } catch (t: Throwable) {
                null
            }
        }
        if (display == null) {
            android.widget.Toast.makeText(ctx, "This device blocked the floating display", android.widget.Toast.LENGTH_LONG).show()
            close(kill = false)
            return
        }
        vd = display
        vdW = w
        vdH = h
        displayId = display.display.displayId

        val comp = component
        if (comp == null) {
            close(kill = false)
            return
        }
        scope.launch {
            ShizukuManager.exec(
                """
                settings put global force_resizable_activities 1
                settings put global enable_freeform_support 1
                am start --display $displayId --user current -n '$comp' -f 0x10000000
                """.trimIndent()
            )
        }
    }

    /** Make the virtual display match the visible area (crisp redraw after resize). */
    private fun applyDisplaySize() {
        val d = vd ?: return
        val w = texture.width
        val h = texture.height
        if (w <= 0 || h <= 0 || (w == vdW && h == vdH)) return
        runCatching {
            surfaceTexture?.setDefaultBufferSize(w, h)
            d.resize(w, h, ctx.resources.displayMetrics.densityDpi)
            vdW = w
            vdH = h
        }
    }

    // ---------------------------------------------------------------- input

    private fun forwardTouch(e: MotionEvent) {
        val svc = ShizukuManager.currentService() ?: return
        if (displayId < 0 || texture.width == 0 || texture.height == 0) return

        val sx = vdW.toFloat() / texture.width
        val sy = vdH.toFloat() / texture.height
        val n = e.pointerCount
        val props = Array(n) { i -> MotionEvent.PointerProperties().also { e.getPointerProperties(i, it) } }
        val coords = Array(n) { i ->
            MotionEvent.PointerCoords().also {
                e.getPointerCoords(i, it)
                it.x *= sx
                it.y *= sy
            }
        }
        val ev = MotionEvent.obtain(
            e.downTime, e.eventTime, e.action, n, props, coords,
            e.metaState, e.buttonState, 1f, 1f, e.deviceId, e.edgeFlags,
            InputDevice.SOURCE_TOUCHSCREEN, e.flags,
        )
        runCatching { svc.injectMotion(ev, displayId) }
        ev.recycle()
    }

    private fun sendKey(code: Int) {
        val svc = ShizukuManager.currentService() ?: return
        if (displayId < 0) return
        val t = SystemClock.uptimeMillis()
        for (action in intArrayOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
            val ev = KeyEvent(
                t, t, action, code, 0, 0,
                KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD,
            )
            runCatching { svc.injectKey(ev, displayId) }
        }
    }

    // ---------------------------------------------------------------- close

    /** Move the app to the normal full screen and close this window. */
    private fun popOut() {
        val comp = component ?: return
        scope.launch {
            ShizukuManager.exec("am start --display 0 --user current -n '$comp'")
            delay(350)
            close(kill = false)
        }
    }

    fun close(kill: Boolean) {
        if (closed) return
        closed = true
        anim?.cancel()
        root.animate().cancel()
        root.animate()
            .scaleX(0.8f).scaleY(0.8f).alpha(0f)
            .setDuration(200)
            .withEndAction { runCatching { wm.removeView(root) } }
            .start()
        scope.launch {
            if (kill) ShizukuManager.exec("am force-stop $pkg")
            release()
            onClosed(this@FloatWindow)
        }
    }

    /** Immediate teardown (service is going away). */
    fun destroyNow() {
        if (closed) return
        closed = true
        anim?.cancel()
        runCatching { wm.removeView(root) }
        release()
    }

    private fun release() {
        runCatching { vd?.release() }
        vd = null
        runCatching { surface?.release() }
        surface = null
        displayId = -1
    }

    // ----------------------------------------------------------------- grip

    private class GripView(context: Context) : View(context) {
        private val d = context.resources.displayMetrics.density
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xAAFFFFFF.toInt()
            strokeWidth = 2f * d
            strokeCap = Paint.Cap.ROUND
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            for (i in 1..2) {
                val o = i * 6f * d
                canvas.drawLine(w - 5f * d, h - o - 5f * d, w - o - 5f * d, h - 5f * d, paint)
            }
        }
    }
}
