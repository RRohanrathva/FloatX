package com.floatx.app.sidebar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.floatx.app.MainActivity
import com.floatx.app.R
import com.floatx.app.data.AppRepository
import com.floatx.app.data.Prefs
import com.floatx.app.window.FloatHostService
import com.floatx.app.ui.FloatXTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SidebarService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var handle: View? = null
    private var panel: ComposeView? = null
    private var panelOwner: OverlayOwner? = null
    private var closing = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        addHandle()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_REFRESH -> {
                removePanelNow()
                addHandle()
            }
            ACTION_STOP -> {
                Prefs.sidebarEnabled = false
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        removePanelNow()
        removeHandle()
        scope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- handle

    private fun addHandle() {
        removeHandle()
        val right = Prefs.rightSide
        val view = HandleView(this, right) { showPanel() }
        val lp = WindowManager.LayoutParams(
            dp(28),
            dp(150),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        }
        runCatching {
            wm.addView(view, lp)
            handle = view
        }
    }

    private fun removeHandle() {
        handle?.let { runCatching { wm.removeView(it) } }
        handle = null
    }

    // ----------------------------------------------------------------- panel

    private fun showPanel() {
        if (panel != null) return
        closing = false
        scope.launch {
            val all = withContext(Dispatchers.IO) { AppRepository.load(this@SidebarService) }
            if (panel != null) return@launch
            val pinned = Prefs.pinned
            val apps = if (pinned.isEmpty()) all else all.filter { it.pkg in pinned }

            val transition = MutableTransitionState(false)
            val owner = OverlayOwner().also { it.start() }
            val rightSide = Prefs.rightSide

            val view = ComposeView(this@SidebarService).apply {
                setViewTreeLifecycleOwner(owner)
                setViewTreeSavedStateRegistryOwner(owner)
                setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
                setContent {
                    FloatXTheme {
                        SidebarPanel(
                            transition = transition,
                            rightSide = rightSide,
                            apps = apps,
                            showingPinned = pinned.isNotEmpty(),
                            onDismiss = { hidePanel(transition) },
                            onLaunch = { pkg ->
                                hidePanel(transition)
                                launchApp(pkg)
                            },
                            onOpenApp = {
                                hidePanel(transition)
                                startActivity(
                                    Intent(this@SidebarService, MainActivity::class.java)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            },
                        )
                    }
                }
            }

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            ).apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }

            runCatching {
                wm.addView(view, lp)
                panel = view
                panelOwner = owner
                transition.targetState = true
            }.onFailure { owner.stop() }
        }
    }

    private fun hidePanel(transition: MutableTransitionState<Boolean>) {
        if (closing) return
        closing = true
        transition.targetState = false
        handler.postDelayed({ removePanelNow() }, 380)
    }

    private fun removePanelNow() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        panelOwner?.stop()
        panelOwner = null
        closing = false
    }

    private fun launchApp(pkg: String) {
        scope.launch {
            delay(120)
            FloatHostService.open(applicationContext, pkg)
        }
    }

    // ---------------------------------------------------------- notification

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_MIN)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SidebarService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_float)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val CHANNEL_ID = "floatx_sidebar"
        private const val NOTIF_ID = 42
        private const val ACTION_REFRESH = "com.floatx.app.REFRESH"
        private const val ACTION_STOP = "com.floatx.app.STOP"

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, SidebarService::class.java))
        }

        fun refresh(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, SidebarService::class.java).setAction(ACTION_REFRESH),
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, SidebarService::class.java))
        }
    }
}
