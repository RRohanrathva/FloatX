package com.floatx.app.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val LightFallback = lightColorScheme(
    primary = Color(0xFF5B45C9),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE5DEFF),
    onPrimaryContainer = Color(0xFF16005A),
    secondary = Color(0xFF605B71),
    secondaryContainer = Color(0xFFE6DFF9),
    onSecondaryContainer = Color(0xFF1C192B),
    tertiary = Color(0xFF7E5260),
    tertiaryContainer = Color(0xFFFFD8E4),
    onTertiaryContainer = Color(0xFF31101D),
    background = Color(0xFFFCF8FF),
    surface = Color(0xFFFCF8FF),
)

private val DarkFallback = darkColorScheme(
    primary = Color(0xFFC9BEFF),
    onPrimary = Color(0xFF2B1599),
    primaryContainer = Color(0xFF4329B0),
    onPrimaryContainer = Color(0xFFE5DEFF),
    secondary = Color(0xFFC9C3DC),
    secondaryContainer = Color(0xFF484459),
    onSecondaryContainer = Color(0xFFE6DFF9),
    tertiary = Color(0xFFEFB8C8),
    tertiaryContainer = Color(0xFF633B48),
    onTertiaryContainer = Color(0xFFFFD8E4),
    background = Color(0xFF141318),
    surface = Color(0xFF141318),
)

val FloatXShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(24.dp),
    large = RoundedCornerShape(32.dp),
    extraLarge = RoundedCornerShape(44.dp),
)

@Composable
fun FloatXTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val colors = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> DarkFallback
        else -> LightFallback
    }
    MaterialTheme(
        colorScheme = colors,
        shapes = FloatXShapes,
        content = content,
    )
}
