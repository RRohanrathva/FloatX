package com.floatx.app.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.IBinder
import android.widget.Toast
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

object ShizukuManager {

    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    private const val REQUEST_CODE = 1001

    data class State(
        val installed: Boolean = false,
        val running: Boolean = false,
        val granted: Boolean = false,
        val bound: Boolean = false,
    ) {
        val ready: Boolean get() = running && granted
    }

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state

    private lateinit var appContext: Context
    @Volatile private var service: IUserService? = null
    @Volatile private var pending: CompletableDeferred<IUserService?>? = null

    private val binderReceived = Shizuku.OnBinderReceivedListener {
        refresh()
        if (_state.value.granted) bind()
    }
    private val binderDead = Shizuku.OnBinderDeadListener {
        service = null
        refresh()
    }
    private val permissionResult =
        Shizuku.OnRequestPermissionResultListener { _, grantResult ->
            refresh()
            if (grantResult == PackageManager.PERMISSION_GRANTED) bind()
        }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) {
                val s = IUserService.Stub.asInterface(binder)
                service = s
                pending?.complete(s)
            }
            refresh()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            refresh()
        }
    }

    /** Already-bound service (non-blocking), or null. */
    fun currentService(): IUserService? = service

    fun init(context: Context) {
        appContext = context.applicationContext
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)
        refresh()
    }

    fun refresh() {
        val installed = runCatching {
            appContext.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        }.isSuccess
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = running && runCatching {
            !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        _state.value = State(installed, running, granted, service != null)
    }

    fun requestPermission(context: Context) {
        if (!_state.value.running) {
            Toast.makeText(context, "Start Shizuku first", Toast.LENGTH_SHORT).show()
            return
        }
        val denied = runCatching { Shizuku.shouldShowRequestPermissionRationale() }.getOrDefault(false)
        if (denied) {
            Toast.makeText(context, "Allow FloatX inside the Shizuku app", Toast.LENGTH_LONG).show()
            openShizuku(context)
        } else {
            runCatching { Shizuku.requestPermission(REQUEST_CODE) }
        }
    }

    fun openShizuku(context: Context) {
        val launch = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
        val intent = launch ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    @Synchronized
    private fun bind() {
        if (service != null) return
        if (pending?.isActive == true) return
        pending = CompletableDeferred()
        runCatching {
            val args = Shizuku.UserServiceArgs(
                ComponentName(appContext.packageName, UserService::class.java.name)
            )
                .daemon(false)
                .processNameSuffix("service")
                .tag("floatx")
                .version(1)
            Shizuku.bindUserService(args, connection)
        }
    }

    private suspend fun awaitService(): IUserService? {
        service?.let { return it }
        refresh()
        if (!_state.value.ready) return null
        bind()
        return withTimeoutOrNull(6000) { pending?.await() }
    }

    /** Runs [command] as the Shizuku user. Returns null when Shizuku isn't ready. */
    suspend fun exec(command: String): String? = withContext(Dispatchers.IO) {
        val s = awaitService() ?: return@withContext null
        runCatching { s.exec(command) }.getOrNull()
    }
}
