package com.floatx.app.shizuku;

import android.view.MotionEvent;
import android.view.KeyEvent;

interface IUserService {
    // Reserved destroy transaction used by Shizuku.
    void destroy() = 16777114;

    // Runs a shell command as the Shizuku user (shell / root) and returns its output.
    String exec(String command) = 1;

    // Inject input into a given (virtual) display. Runs with shell privileges.
    oneway void injectMotion(in MotionEvent event, int displayId) = 2;
    oneway void injectKey(in KeyEvent event, int displayId) = 3;
}
