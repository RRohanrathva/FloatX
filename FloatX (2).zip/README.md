# FloatX

Floating app windows for Android 11 – 17 using **Shizuku**, in the style of Mi-Freeform:
each app runs on a private virtual display shown inside FloatX's own window.

## Window controls
- **Drag the top bar** to move. Drag it to the top edge, or double-tap it, for fullscreen.
- **Drag the corner grip** (bottom-right) to resize.
- **×** close (stops the app) · **□** fullscreen toggle (swipe the bar down to leave) ·
  **↗** move the app to the normal full screen · **‹** back.
- Edge sidebar: swipe the pill on the screen edge to pick an app.

## Build on GitHub
Upload `FloatX.zip` + `.github/workflows/build.yml`, open Actions, download `FloatX-apk`.

## Setup on the phone
1. Start Shizuku. 2. Grant FloatX in Shizuku. 3. Allow display over other apps. 4. Turn on Edge sidebar.

## Known limits
- Typing with the keyboard inside a floating window may not work on some ROMs.
- Some ROMs/Android versions restrict virtual displays; the app shows a message if blocked.
